package com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.network.models_dto.Filter.FilterViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.repository.SharedPrefence
/**FILTERS**/
var alertProveedorOcupacion = mutableStateOf(false)

var alertClientesFilter = mutableStateOf(false)

var alertRegionFilter = mutableStateOf(false)

var alertSalasFilter = mutableStateOf(false)

var alertstateHours = mutableStateOf(false)

var alertObjetivoSemanal = mutableStateOf(false)

var alertProveedorLoMasJugado = mutableStateOf(false)

var alertProveedorAcumulados = mutableStateOf(false)

var alertJuegosFilter = mutableStateOf(false)

var alertJuegosComentariosJugadores = mutableStateOf(false)

var alertProveedorSonido = mutableStateOf(false)

var alertObservacionesCompetecia = mutableStateOf(false)

var alertDetalleSave = mutableStateOf(false)

var alertLibreriaOcupacion = mutableStateOf(false)

var alertLibreriaOcupacionSlots = mutableStateOf(false)

var alertSubJuegosOcupacion = mutableStateOf(false)




@Composable
fun DisplayAlert(
    viewModel: PromotorNuevaVisitaViewModel,
    viewModel2: FilterViewModel,
    modifier: Modifier = Modifier,
    onDialogStateChange: ((Boolean) -> Unit)? = null,
    onDismissRequest: (() -> Unit)? = null,
    navController: NavController
    ){
    val context: Context = LocalContext.current
    val textPaddingAll = 0.dp
    val dialogShape = RoundedCornerShape(18.dp)
    val datastore = SharedPrefence(LocalContext.current)
    val token = datastore.getToken().toString()
    val cliente = datastore.getCliente().toString()
    val idsala = datastore.getSalaId()
    val idcliente = datastore.getIDCliente()

    /**Alert Dialog**/
    Box(modifier = Modifier
        .background(Color.Black)
        .fillMaxSize()
        .clickable {
            navController.popBackStack()
        }
    ) {
        if (alertstateHours.value) {
            AlertDialog(
                onDismissRequest = {
                    onDialogStateChange?.invoke(false)
                    onDismissRequest?.invoke()
                },
                title = null,
                buttons = {
                    Box(
                        modifier = Modifier
                            .height(60.dp)
                            .fillMaxWidth()
                            .background(color = colorResource(R.color.reds))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(horizontal = 10.dp)
                                    .clickable {
                                        alertstateHours.value = false
                                        navController.popBackStack()
                                    }
                            )
                            Text(
                                text = "SELECCIONA LOS HORARIOS",
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                    LazyColumn() {
                        item {
                            viewModel.dataTime.forEach { items ->
                                Row(Modifier.padding(all = textPaddingAll)) {
                                    val isChecked = remember { mutableStateOf(items.check) }
                                    Checkbox(
                                        checked = isChecked.value,
                                        onCheckedChange = {
                                            isChecked.value = it
                                            viewModel.postTimeCheck(isChecked.value, items.time)
                                        }
                                    )
                                    Text(
                                        text = "${items.time}:00 hrs",
                                        modifier = Modifier.align(Alignment.CenterVertically)
                                    )
                                }
                                Divider(color = Color.DarkGray, thickness = 3.dp)
                            }
                            Button(
                                onClick = {
                                    alertstateHours.value = false
                                    navController.popBackStack()
                                },
                                modifier = Modifier
                                    .padding(5.dp)
                                    .fillMaxWidth()
                                    .height(60.dp),
                                elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                                shape = RoundedCornerShape(10),
                                colors = ButtonDefaults.buttonColors(
                                    backgroundColor = colorResource(id = com.example.zitrocrm.R.color.reds)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Precio Inicio",
                                )
                            }
                        }
                    }
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                ),
                modifier = modifier,
                shape = dialogShape
            )
        }
        if (alertClientesFilter.value) {
            AlertDialog(
                onDismissRequest = {
                    onDialogStateChange?.invoke(false)
                    onDismissRequest?.invoke()
                },
                title = null,
                buttons = {
                    Box(
                        modifier = Modifier
                            .height(60.dp)
                            .fillMaxWidth()
                            .background(color = colorResource(R.color.reds))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(horizontal = 10.dp)
                                    .clickable {
                                        alertClientesFilter.value = false
                                        navController.popBackStack()
                                    }
                            )
                            Text(
                                text = "SELECCIONA EL CLIENTE",
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                    LazyColumn() {
                        item {
                            viewModel2.clientesFilter .forEach { label ->
                                Column(modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        navController.popBackStack()
                                        viewModel.getFoliosTecnicos(token,idsala!!.toInt(),idcliente!!.toInt())
                                        viewModel2.selectClientes(
                                            id = label.id!!,
                                            nombre = label.nombre!!,
                                            context
                                        )
                                    }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                    Text(text = label.nombre.toString())
                                }
                            }
                        }
                    }
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                ),
                modifier = modifier,
                shape = dialogShape
            )
        }
        if (alertRegionFilter.value) {
            AlertDialog(
                onDismissRequest = {
                    onDialogStateChange?.invoke(false)
                    onDismissRequest?.invoke()
                },
                title = null,
                buttons = {
                    Box(
                        modifier = Modifier
                            .height(60.dp)
                            .fillMaxWidth()
                            .background(color = colorResource(R.color.reds))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(horizontal = 10.dp)
                                    .clickable {
                                        alertRegionFilter.value = false
                                        navController.popBackStack() }
                            )
                            Text(
                                text = "SELECCIONA LA REGION",
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                    LazyColumn() {
                        item {
                            viewModel2.regionesFilter.forEach { label ->
                                Column(modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        navController.popBackStack()
                                        viewModel2.selectRegiones(
                                            id = label.id!!,
                                            nombre = label.nombre!!,
                                            context,
                                            token = token, cliente
                                        )
                                        //viewModel2.getSalasFilter(token = token,cliente,label.id!!.toInt())
                                    }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                    Text(text = label.nombre.toString())
                                }
                            }
                        }
                    }
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                ),
                modifier = modifier,
                shape = dialogShape
            )
        }
        if (alertSalasFilter.value) {
            AlertDialog(
                onDismissRequest = {
                    onDialogStateChange?.invoke(false)
                    onDismissRequest?.invoke()
                },
                title = null,
                buttons = {
                    Box(
                        modifier = Modifier
                            .height(60.dp)
                            .fillMaxWidth()
                            .background(color = colorResource(R.color.reds))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(horizontal = 10.dp)
                                    .clickable {
                                        alertSalasFilter.value = false
                                        navController.popBackStack()
                                        viewModel.getFoliosTecnicos(token,idsala!!.toInt(),idcliente!!.toInt())
                                    }
                            )
                            Text(
                                text = "SELECCIONA LA SALA",
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                    LazyColumn() {
                        item {
                            viewModel2.salasFilter.forEach { label ->
                                Column(modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        navController.popBackStack()
                                        viewModel.getFoliosTecnicos(token,label.id!!.toInt(),idcliente!!.toInt())
                                        viewModel2.selectSalas(
                                            id = label.id!!,
                                            nombre = label.nombre!!,
                                            cliente = label.cliente!!,
                                            context
                                        )
                                    }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                    Text(text = label.nombre.toString())
                                }
                            }
                        }
                    }
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                ),
                modifier = modifier,
                shape = dialogShape
            )
        }
        if (alertObjetivoSemanal.value) {
            AlertDialog(
                onDismissRequest = {
                    onDialogStateChange?.invoke(false)
                    onDismissRequest?.invoke()
                },
                title = null,
                buttons = {
                    Box(
                        modifier = Modifier
                            .height(60.dp)
                            .fillMaxWidth()
                            .background(color = colorResource(R.color.reds))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .align(Alignment.Center)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(horizontal = 10.dp)
                                    .clickable {
                                        alertObjetivoSemanal.value = false
                                        navController.popBackStack()
                                    }
                            )
                            Text(
                                text = "SELECCIONA OBJETIVO SEMANAL",
                                modifier = Modifier.align(Alignment.CenterVertically)
                            )
                        }
                    }
                    LazyColumn() {
                        item {
                            viewModel.objetivoSemanal.forEach { items ->
                                Column(modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        navController.popBackStack()
                                        viewModel.addItemObjetivo(
                                            items.id!!.toInt(), items.objetivo.toString()
                                        )
                                        alertObjetivoSemanal.value = false
                                    }
                                    .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                    Text(text = items.objetivo.toString())
                                }
                            }
                        }
                    }
                },
                properties = DialogProperties(
                    dismissOnBackPress = true,
                    dismissOnClickOutside = false
                ),
                modifier = modifier,
                shape = dialogShape
            )
        }
    }
    if (alertProveedorOcupacion.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertProveedorOcupacion.value = false
                                    navController.popBackStack()

                                }
                        )
                        Text(
                            text = "SELECCIONA EL PROVEEDOR",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.proveedorOcupacion.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectProveedorOcupacion(
                                        token = token,
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertProveedorAcumulados.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertProveedorAcumulados.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PROVEEDOR",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.proveedorOcupacion.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.selectProveedorAcumulados(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                    navController.popBackStack()
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertLibreriaOcupacionSlots.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertLibreriaOcupacionSlots.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA LA LIBRERIA",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.librerias_ocupacion.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectLibreriaOcupacion(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                        tipo = label.tipo!!
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertLibreriaOcupacion.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertLibreriaOcupacion.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA LA LIBRERIA",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.juegosFilter.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectLibreriaOcupacion(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                        tipo = 0
                                    )
                                    viewModel.getJuegosOcupacion(token,label.id!!)
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertProveedorLoMasJugado.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertProveedorLoMasJugado.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PROVEEDOR",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.proveedorOcupacion.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectProveedorLoMasJugado(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertJuegosFilter.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertJuegosFilter.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PRODUCTO",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.juegosFilter.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectJuegoMasJugado(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertJuegosComentariosJugadores.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertJuegosComentariosJugadores.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PRODUCTO",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.juegosFilter.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectJuegoComentGeneralesJugadores(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertProveedorSonido.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertProveedorSonido.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PROVEEDOR",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        viewModel.proveedorOcupacion.forEach { label ->
                            Column(modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.popBackStack()
                                    viewModel.selectProveedorSonido(
                                        id = label.id!!,
                                        nombre = label.nombre!!,
                                    )
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                Text(text = label.nombre.toString())
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    if (alertObservacionesCompetecia.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertObservacionesCompetecia.value = false
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "SELECCIONA EL PROVEEDOR",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                Column(modifier = Modifier
                    .verticalScroll(state = ScrollState(1))) {
                    viewModel.proveedorOcupacion.forEach { label ->
                        Column(modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                navController.popBackStack()
                                viewModel.selectProvedorObservaciones(
                                    id = label.id!!,
                                    nombre = label.nombre!!,
                                )
                            }
                            .padding(horizontal = 20.dp, vertical = 10.dp)) {
                            Text(text = label.nombre.toString())
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }
    /*if (alertDetalleSave.value) {
        AlertDialog(
            onDismissRequest = {
                onDialogStateChange?.invoke(false)
                onDismissRequest?.invoke()
            },
            title = null,
            buttons = {
                Box(
                    modifier = Modifier
                        .height(60.dp)
                        .fillMaxWidth()
                        .background(color = colorResource(R.color.reds))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 10.dp)
                                .clickable {
                                    alertDetalleSave.value = false
                                    viewModel.networkstate_ID.value = 0
                                    navController.popBackStack()
                                }
                        )
                        Text(
                            text = "DETALLE DE ENVIO DEL REPORTE",
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
                LazyColumn() {
                    item {
                        Column(modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 10.dp)) {
                            if(viewModel.networkstate_ID.value>0){
                                Text(text = "Se Guardo Correctamente",
                                    modifier = Modifier.align(CenterHorizontally)
                                )
                                Text(text = "ID DEL REPORTE: "+viewModel.networkstate_ID.value.toString(),
                                    modifier = Modifier.align(CenterHorizontally)
                                )
                            }else if (viewModel.networkstate_ID.value==0){
                                Text(text = "! ERROR ¡ COMPRUEBA TU INFORMACION "+viewModel.networkstate.value,
                                    modifier = Modifier.align(CenterHorizontally)
                                )
                            }
                            Button(
                                onClick = {
                                    alertDetalleSave.value = false
                                    navController.popBackStack()
                                    viewModel.networkstate_ID.value = 0
                                },
                                modifier = Modifier
                                    .padding(5.dp)
                                    .fillMaxWidth()
                                    .height(60.dp),
                                elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                                shape = RoundedCornerShape(10),
                                colors = ButtonDefaults.buttonColors(
                                    backgroundColor = colorResource(id = com.example.zitrocrm.R.color.reds)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Precio Inicio",
                                )
                            }
                        }
                    }
                }
            },
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            ),
            modifier = modifier,
            shape = dialogShape
        )
    }*/
}
