package com.example.zitrocrm.network.models_dto.Filter

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.zitrocrm.network.models_dto.Filter.ClienteFilter.Clientes
import com.example.zitrocrm.network.models_dto.Filter.RegionesFilter.Regiones
import com.example.zitrocrm.network.models_dto.Filter.SalasFilter.Salas
import com.example.zitrocrm.network.repository.RetrofitHelper
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertClientesFilter
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertRegionFilter
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertSalasFilter
import com.example.zitrocrm.repository.SharedPrefence
import com.example.zitrocrm.screens.login.components.progressBar
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class FilterViewModel @Inject constructor() : ViewModel() {

    var clientesFiltro = mutableStateOf("")
    var regionesFiltro = mutableStateOf("")
    var salasFiltro = mutableStateOf("")
    val clientesFilter: MutableList<Clientes> = arrayListOf()
    val regionesFilter: MutableList<Regiones> = arrayListOf()
    val salasFilter : MutableList<Salas> = arrayListOf()



    fun selectClientes (id:Int, nombre:String, context: Context){
        clientesFiltro.value = nombre
        val dataStorePreferenceRepository = SharedPrefence(context)
        dataStorePreferenceRepository.saveCLiente(id,nombre)
        dataStorePreferenceRepository.saveRegiones(0,"")
        dataStorePreferenceRepository.saveSala(0,"","")
        alertClientesFilter.value=false
    }
    fun selectRegiones (id:Int, nombre:String, context: Context,token: String,cliente: String){
        regionesFiltro.value = nombre
        val dataStorePreferenceRepository = SharedPrefence(context)
        dataStorePreferenceRepository.saveRegiones(id,nombre)
        alertRegionFilter.value=false
        getSalasFilter(token = token,cliente,id)
    }
    fun selectSalas (id:Int, nombre:String,cliente: String, context: Context){
        salasFiltro.value = nombre
        val dataStorePreferenceRepository = SharedPrefence(context)
        dataStorePreferenceRepository.saveSala(id,nombre,cliente)
        alertSalasFilter.value=false
    }

    fun addClientesFilter(id:Int, nombre:String){
        clientesFilter.filter { it.id == id }.forEach {
            clientesFilter.remove(Clientes(id = id,nombre = nombre))
        }
        clientesFilter.add(Clientes(id = id,nombre = nombre))
    }

    fun addRegionFilter(id:Int, nombre:String){
        regionesFilter.filter { it.id == id }.forEach {
            regionesFilter.remove(Regiones(id = id,nombre = nombre))
        }
        regionesFilter.add(Regiones(id = id, nombre = nombre))
    }

    fun addSalaFilter(id:Int, nombre:String, cliente: String){
        salasFilter.add(Salas(id = id, nombre = nombre,cliente = cliente))
    }

    fun getFilters(token:String) {
        viewModelScope.launch(Dispatchers.IO) {
            val authService = RetrofitHelper.getAuthService()
            /**FILTER CLIENTES**/
            try {
                progressBar.value = true
                val responseService = authService.getCliente(token)
                if (responseService.ok!!){
                    responseService.clientes.forEach{Response ->
                        addClientesFilter(id = Response.id!!.toInt(), nombre = Response.nombre.toString())
                    }
                }else {
                    Log.d("filter", "ELSE CLIENTES")
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER CLIENTE FAIL", e)
            }
            /**FILTER REGIONES**/
            try {
                progressBar.value = true
                val responseService = authService.getRegiones(token)

                if (responseService.ok!!){
                    responseService.regiones.forEach{Response ->
                        addRegionFilter(id = Response.id!!.toInt(), nombre = Response.nombre.toString())
                    }
                }else{
                    Log.d("filter", "ELSE REGIONES")
                }
                progressBar.value = false
            }catch (e:Exception){
                progressBar.value = false
                Log.d("Exception", "FILTER REGIONES FAIL", e)
            }
            progressBar.value = false
        }
    }

    fun getSalasFilter(token: String, cliente: String, region:Int){
        viewModelScope.launch(Dispatchers.IO) {
            val authService = RetrofitHelper.getAuthService()
            /**FILTER SALAS**/
            try {
                progressBar.value = true
                salasFilter.clear()
                val responseService = authService.getSala(token,cliente,region)
                if (responseService.ok!!) {
                    responseService.salas.forEach { Response ->
                        addSalaFilter(
                            id = Response.id!!.toInt(),
                            nombre = Response.nombre.toString(),
                            cliente = Response.cliente.toString()
                        )
                    }
                } else {
                    Log.d("filter", "ELSE SALAS")
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER SALAS FAIL", e)
            }
        }
    }
}