package com.example.zitrocrm.screens.salas.PromotorNuevaVisita.ExpandedScreens

import android.annotation.SuppressLint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.TextFormat
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.zitrocrm.R
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.SampleData
import com.example.zitrocrm.screens.salas.*
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.ui.theme.blackdark
import com.example.zitrocrm.utils.Val_Constants

@ExperimentalAnimationApi
@SuppressLint("UnusedTransitionTargetStateParameter")
@Composable
fun ObjetivoVisitaCard(
    card3: SampleData,
    onCardArrowClick: () -> Unit,
    expanded: Boolean,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel
) {
    val transitionState = remember { MutableTransitionState(expanded).apply {
        targetState = !expanded
    }}
    val transition = updateTransition(targetState = transitionState, label = "transition")
    val cardBgColor by transition.animateColor({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "bgColorTransition") {
        if (expanded) blackdark else blackdark
    }
    val cardElevation by transition.animateDp({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "elevationTransition") {
        if (expanded) 20.dp else 5.dp
    }
    val cardRoundedCorners by transition.animateDp({
        tween(
            durationMillis = Val_Constants.ExpandAnimation,
            easing = FastOutSlowInEasing
        )
    }, label = "cornersTransition") {
        15.dp
    }
    val arrowRotationDegree by transition.animateFloat({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "rotationDegreeTransition") {
        if (expanded) 0f else 180f
    }
    Card(
        backgroundColor = cardBgColor,
        elevation = cardElevation,
        shape = RoundedCornerShape(cardRoundedCorners),
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                vertical = 4.dp
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Box {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)){
                        Image(painter = painterResource(id = R.drawable.lista_de_verificacion),
                            contentDescription ="IconList",
                            modifier = Modifier
                                .padding(start = 10.dp))
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                    ) {
                        Text(
                            text = card3.title,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 25.dp
                                )
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)
                    ) {
                        CardArrow(
                            degrees = arrowRotationDegree,
                            onClick = onCardArrowClick
                        )
                    }
                }
            }
            ObjetivoVisitaExpand(expanded,viewModelPromotorNuevaVisita)
        }
    }
}

@ExperimentalAnimationApi
@Composable
fun ObjetivoVisitaExpand(
    expanded: Boolean = true,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel
) {

    AnimatedVisibility(
        visible = expanded,
        enter = enterExpand + enterFadeIn,
        exit = exitCollapse + exitFadeOut
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(8.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()) {
                Column(modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 10.dp)
                ) {

                    Text(text = "Objetivo",
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(vertical = 10.dp),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 19.sp)
                    OutlinedTextField(
                        value = viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value,
                        onValueChange = { viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it },
                        label = { Text("Objetivo") },
                        modifier = Modifier
                            .fillMaxWidth(),
                        leadingIcon = {
                            IconButton(onClick = { }) {
                                Icon(
                                    imageVector = Icons.Filled.TextFormat,
                                    contentDescription = "Botón para elegir fecha"
                                )
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = viewModelPromotorNuevaVisita.queHacer_visita.value,
                        onValueChange = { viewModelPromotorNuevaVisita.queHacer_visita.value = it },
                        label = { Text("¿Qué haces para lograr el Objetivo?") },
                        modifier = Modifier
                            .fillMaxWidth(),
                        leadingIcon = {
                            IconButton(onClick = { }) {
                                Icon(
                                    imageVector = Icons.Filled.TextFormat,
                                    contentDescription = "Botón para elegir fecha"
                                )
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.align(Alignment.CenterHorizontally)){
                        Text(text = "        - ",
                            modifier = Modifier
                                .padding(vertical = 10.dp),
                            style = MaterialTheme.typography.subtitle2,
                            textAlign = TextAlign.Center,
                            fontSize = 15.sp)
                        Text(text = "¿Se logro el objetivo?",
                            modifier = Modifier
                                .padding(vertical = 10.dp),
                            style = MaterialTheme.typography.subtitle2,
                            textAlign = TextAlign.Center,
                            fontSize = 15.sp)
                        Spacer(Modifier.width(10.dp))
                        Checkbox(
                            modifier = Modifier
                                .padding(start = 5.dp)
                                .align(Alignment.CenterVertically),
                            checked = viewModelPromotorNuevaVisita.seLogro_visita.value,
                            onCheckedChange = { viewModelPromotorNuevaVisita.seLogro_visita.value = it }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = viewModelPromotorNuevaVisita.por_que_objetivo.value,
                        onValueChange = { viewModelPromotorNuevaVisita.por_que_objetivo.value = it },
                        label = { Text("¿Por que?") },
                        modifier = Modifier
                            .fillMaxWidth(),
                        leadingIcon = {
                            IconButton(onClick = { }) {
                                Icon(
                                    imageVector = Icons.Filled.QuestionAnswer,
                                    contentDescription = "Botón para elegir fecha"
                                )
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}
