package com.example.zitrocrm.screens.salas

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.navigation.Destination
import com.example.zitrocrm.network.models_dto.Filter.FilterViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.ExpandedScreens.*
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertDetalleSave
import com.example.zitrocrm.ui.theme.reds
import com.example.zitrocrm.repository.SharedPrefence
import com.example.zitrocrm.utils.Val_Constants.CollapseAnimation
import com.example.zitrocrm.utils.Val_Constants.ExpandAnimation
import com.example.zitrocrm.utils.Val_Constants.FadeInAnimation
import com.example.zitrocrm.utils.Val_Constants.FadeOutAnimation

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun PromotorNewScreenn (
    navController: NavController,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    viewModelFilter: FilterViewModel,
    modifier: Modifier = Modifier,
    onDialogStateChange: ((Boolean) -> Unit)? = null,
    onDismissRequest: (() -> Unit)? = null,
){
    val datastore = SharedPrefence(LocalContext.current)
    val cliente = ""+datastore.getCliente().toString()
    val region = ""+datastore.getRegion().toString()
    val sala = ""+datastore.getSala().toString()
    val salaid = datastore.getSalaId()
    val clienteid = datastore.getIDCliente().toString()
    val token = datastore.getToken().toString()
    val cards = viewModelPromotorNuevaVisita.cards.collectAsState()
    val cards2 = viewModelPromotorNuevaVisita.cards2.collectAsState()
    val cards3 = viewModelPromotorNuevaVisita.cards3.collectAsState()
    val cards4 = viewModelPromotorNuevaVisita.cards4.collectAsState()
    val cards5 = viewModelPromotorNuevaVisita.cards5.collectAsState()
    val cards6 = viewModelPromotorNuevaVisita.cards6.collectAsState()
    val cards7 = viewModelPromotorNuevaVisita.cards7.collectAsState()
    val cards8 = viewModelPromotorNuevaVisita.cards8.collectAsState()
    val cards9 = viewModelPromotorNuevaVisita.cards9.collectAsState()
    val expandedCard = viewModelPromotorNuevaVisita.expandedCardList.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar(
                elevation = 0.dp,
                modifier = Modifier.height(70.dp),
                title = {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier
                            .align(alignment = Alignment.CenterStart)
                            .padding(start = 35.dp)) {
                            Text(text = "FILTROS DE BUSQUEDA ", fontSize = 9.sp, color = Color.White)
                            Text(text = "Cliente: "+cliente, fontSize = 7.sp, color = Color.White)
                            Text(text = "Region: "+region, fontSize = 7.sp, color = Color.White)
                            Text(text = "Sala: "+sala, fontSize = 7.sp, color = Color.White)
                        }
                        Image(
                            painter = painterResource(R.drawable.back_button),
                            contentDescription = "",
                            modifier = Modifier
                                .clickable {
                                    navController.popBackStack()
                                }
                                .align(Alignment.CenterStart)
                                .size(29.dp),
                        )
                        Image(
                            painter = painterResource(R.drawable.crm_logo),
                            contentDescription = "",
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(5.dp)
                        )
                        Row(modifier = Modifier.align(Alignment.CenterEnd)) {
                            if(viewModelPromotorNuevaVisita.statecheckBingo.value==false) {
                                Text(text = "Bingo",
                                    modifier = Modifier.align(CenterVertically),
                                    style = MaterialTheme.typography.subtitle2,
                                    fontSize = 10.sp,
                                    color = Color.Green
                                )
                            }else {
                                Text(text = "Bingo",
                                    modifier = Modifier.align(CenterVertically),
                                    style = MaterialTheme.typography.subtitle2,
                                    fontSize = 10.sp,
                                    color = Color.White
                                )
                            }
                            Switch(
                                checked = viewModelPromotorNuevaVisita.statecheckBingo.value,
                                onCheckedChange = {
                                    viewModelPromotorNuevaVisita.statecheckBingo.value = it
                                    viewModelPromotorNuevaVisita.checkSwitchBingoSlots(token)
                                },
                                modifier = Modifier.align(CenterVertically),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    uncheckedThumbColor = Color.White,
                                    checkedTrackColor = Color.LightGray,
                                    uncheckedTrackColor = Color.DarkGray,
                                    checkedTrackAlpha = 1.0f,
                                    uncheckedTrackAlpha = 1.0f
                                )
                            )
                            if(viewModelPromotorNuevaVisita.statecheckBingo.value==true) {
                                Text(text = "Slots",
                                    modifier = Modifier.align(CenterVertically),
                                    style = MaterialTheme.typography.subtitle2,
                                    fontSize = 10.sp,
                                    color = Color.Green
                                )
                            }else {
                                Text(text = "Slots",
                                    modifier = Modifier.align(CenterVertically),
                                    style = MaterialTheme.typography.subtitle2,
                                    fontSize = 10.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                },
                backgroundColor = reds,
            )
        },
        floatingActionButtonPosition = FabPosition.End,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    viewModelFilter.getFilters(token)
                    navController.navigate(route = Destination.FilterScreen.route)
                }
            )
            {
                Image(
                    painter = painterResource(R.drawable.button_filter_icon),
                    contentDescription = "",
                    modifier = Modifier
                        .size(57.dp)
                        .clip(CircleShape)
                        .clickable {
                            viewModelFilter.getFilters(token)
                            navController.navigate(route = Destination.FilterScreen.route
                            )
                        }
                )
            } },
    )
    {
        Scaffold {
            if (alertDetalleSave.value) {
                AlertDialog(
                    onDismissRequest = {
                        onDialogStateChange?.invoke(false)
                        onDismissRequest?.invoke()
                    },
                    title = null,
                    buttons = {
                        Box(
                            modifier = Modifier
                                .height(60.dp)
                                .fillMaxWidth()
                                .background(color = colorResource(R.color.reds))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .align(Alignment.Center)
                            ) {
                                Icon(
                                    Icons.Filled.ArrowBack, "Hora", modifier = Modifier
                                        .align(Alignment.CenterVertically)
                                        .padding(horizontal = 10.dp)
                                        .clickable {
                                            alertDetalleSave.value = false
                                            viewModelPromotorNuevaVisita.networkstate_ID.value = 0
                                        }
                                )
                                Text(
                                    text = "DETALLE DE ENVIO DEL REPORTE",
                                    modifier = Modifier.align(Alignment.CenterVertically)
                                )
                            }
                        }
                        LazyColumn() {
                            item {
                                Column(modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 10.dp)) {
                                    if(viewModelPromotorNuevaVisita.networkstate_ID.value>0){
                                        Text(text = "Se Guardo Correctamente",
                                            modifier = Modifier.align(Alignment.CenterHorizontally)
                                        )
                                        Text(text = "ID DEL REPORTE: "+viewModelPromotorNuevaVisita.networkstate_ID.value.toString(),
                                            modifier = Modifier.align(Alignment.CenterHorizontally)
                                        )
                                    }else if (viewModelPromotorNuevaVisita.networkstate_ID.value==0){
                                        Text(text = "! ERROR ¡ COMPRUEBA TU INFORMACION "+viewModelPromotorNuevaVisita.networkstate.value,
                                            modifier = Modifier.align(Alignment.CenterHorizontally)
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            alertDetalleSave.value = false
                                            viewModelPromotorNuevaVisita.networkstate_ID.value = 0
                                        },
                                        modifier = Modifier
                                            .padding(5.dp)
                                            .fillMaxWidth()
                                            .height(60.dp),
                                        elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                                        shape = RoundedCornerShape(10),
                                        colors = ButtonDefaults.buttonColors(
                                            backgroundColor = colorResource(id = com.example.zitrocrm.R.color.reds)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Precio Inicio",
                                        )
                                    }
                                }
                            }
                        }
                    },
                    properties = DialogProperties(
                        dismissOnBackPress = true,
                        dismissOnClickOutside = false
                    ),
                    modifier = modifier,
                    shape = RoundedCornerShape(18.dp)
                )
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp)
                ) {
                    LazyColumn {
                        itemsIndexed(cards.value) { _, card ->
                            VisitaPromotoresCard(
                                card = card,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card.id) },
                                expanded = expandedCard.value.contains(card.id), viewModelPromotorNuevaVisita,navController
                            )
                        }
                        itemsIndexed(cards2.value) { _, card2 ->
                            DetalleOcupacionCard(
                                card2 = card2,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card2.id) },
                                expanded = expandedCard.value.contains(card2.id),viewModelPromotorNuevaVisita,navController
                            )
                        }
                        itemsIndexed(cards3.value) { _, card3 ->
                            ObjetivoVisitaCard(
                                card3 = card3,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card3.id) },
                                expanded = expandedCard.value.contains(card3.id),viewModelPromotorNuevaVisita
                            )
                        }
                        if(viewModelPromotorNuevaVisita.statecheckBingo.value == false) {
                            itemsIndexed(cards4.value) { _, card4 ->
                                AcumuladosBingoCard(
                                    card4 = card4,
                                    onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card4.id) },
                                    expanded = expandedCard.value.contains(card4.id),viewModelPromotorNuevaVisita,navController
                                )
                            }
                        }
                        itemsIndexed(cards5.value) { _, card5 ->
                            JugadoZitroCompetencia(
                                card5 = card5,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card5.id) },
                                expanded = expandedCard.value.contains(card5.id),viewModelPromotorNuevaVisita, navController
                            )
                        }
                        itemsIndexed(cards6.value) { _, card6 ->
                            ComentariosGeneralesJugadores(
                                card6 = card6,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card6.id) },
                                expanded = expandedCard.value.contains(card6.id),viewModelPromotorNuevaVisita, navController
                            )
                        }
                        /*itemsIndexed(cards7.value) { _, card7 ->
                            ComentariosSonidoZitroComp(
                                card7 = card7,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card7.id) },
                                expanded = expandedCard.value.contains(card7.id),viewModelPromotorNuevaVisita, navController
                            )
                        }*/
                        itemsIndexed(cards8.value) { _, card8->
                            ObservacionesCompetencia(
                                card8 = card8,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card8.id) },
                                expanded = expandedCard.value.contains(card8.id),viewModelPromotorNuevaVisita, navController
                            )
                        }
                        itemsIndexed(cards9.value) { _, card9->
                            FoliosTecnicos(
                                card9 = card9,
                                onCardArrowClick = { viewModelPromotorNuevaVisita.cardArrowClick(card9.id) },
                                expanded = expandedCard.value.contains(card9.id),viewModelPromotorNuevaVisita
                            )
                        }
                        item {
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    viewModelPromotorNuevaVisita.postVisitaPromotoresSala(token,salaid!!.toInt())
                                },
                                modifier = Modifier
                                    .padding(horizontal = 50.dp)
                                    .fillMaxWidth()
                                    .height(60.dp),
                                elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                                shape = RoundedCornerShape(10),
                                colors = ButtonDefaults.buttonColors(backgroundColor = colorResource(id = R.color.reds)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Precio Inicio",
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun CardArrow(
    degrees: Float,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        content = {
            Icon(
                painter = painterResource(id = R.drawable.ic_arrow_down),
                contentDescription = "Expandable Arrow",
                modifier = Modifier
                    .rotate(degrees)
                    .size(30.dp),
            )
        }
    )
}

val enterFadeIn = fadeIn(
    animationSpec = TweenSpec(
        durationMillis = FadeInAnimation,
        easing = FastOutLinearInEasing
    )
)
val enterExpand = expandVertically(
    animationSpec = tween(ExpandAnimation
    )
)
val exitFadeOut = fadeOut(
    animationSpec = TweenSpec(
        durationMillis = FadeOutAnimation,
        easing = LinearOutSlowInEasing
    )
)
val exitCollapse =
    shrinkVertically(animationSpec = tween(CollapseAnimation))