package com.example.zitrocrm.screens.login

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.zitrocrm.network.models_dto.Login.LoginDto
import com.example.zitrocrm.network.repository.RetrofitHelper
import com.example.zitrocrm.repository.SharedPrefence
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LoginViewModel (
) : ViewModel() {
    val isSuccessLoading = mutableStateOf(value = false)
    val imageErrorAuth = mutableStateOf(value = false)
    val progressBar = mutableStateOf(value = false)

    fun login(user: String, pwd: String, context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                progressBar.value = true
                delay(1500L)
                val authService = RetrofitHelper.getAuthService()
                val responseService = authService.getLogin(LoginDto(usuario = user, pwd = pwd))
                if (responseService.ok!!) {
                    val token = responseService.token
                    val dataStorePreferenceRepository = SharedPrefence(context)
                    isSuccessLoading.value = true
                    dataStorePreferenceRepository.saveUser(user, pwd, responseService.usuario!!, token!!)
                } else {
                    imageErrorAuth.value = true
                    delay(1500L)
                    imageErrorAuth.value = false
                }
                //loginRequestLiveData.postValue(responseService.isSuccessful)
                progressBar.value = false
            } catch (e: Exception) {
                Log.d("Logging", "Error Authentication", e)
                progressBar.value = false
            }
        }
    }
}
