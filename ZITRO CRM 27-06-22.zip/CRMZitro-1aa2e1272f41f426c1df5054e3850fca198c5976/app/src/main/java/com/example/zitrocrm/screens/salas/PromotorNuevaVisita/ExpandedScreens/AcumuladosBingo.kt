package com.example.zitrocrm.screens.salas.PromotorNuevaVisita.ExpandedScreens

import android.annotation.SuppressLint
import android.app.TimePickerDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.navigation.Destination
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.SampleData
import com.example.zitrocrm.screens.salas.*
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertProveedorAcumulados
import com.example.zitrocrm.ui.theme.blackdark
import com.example.zitrocrm.ui.theme.graydark
import com.example.zitrocrm.utils.Val_Constants
import java.util.*

@ExperimentalAnimationApi
@SuppressLint("UnusedTransitionTargetStateParameter")
@Composable
fun AcumuladosBingoCard(
    card4: SampleData,
    onCardArrowClick: () -> Unit,
    expanded: Boolean,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    navController: NavController

) {
    val transitionState = remember { MutableTransitionState(expanded).apply {
        targetState = !expanded
    }}
    val transition = updateTransition(targetState = transitionState, label = "transition")
    val cardBgColor by transition.animateColor({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "bgColorTransition") {
        if (expanded) blackdark else blackdark
    }
    val cardElevation by transition.animateDp({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "elevationTransition") {
        if (expanded) 20.dp else 5.dp
    }
    val cardRoundedCorners by transition.animateDp({
        tween(
            durationMillis = Val_Constants.ExpandAnimation,
            easing = FastOutSlowInEasing
        )
    }, label = "cornersTransition") {
        15.dp
    }
    val arrowRotationDegree by transition.animateFloat({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "rotationDegreeTransition") {
        if (expanded) 0f else 180f
    }

    Card(
        backgroundColor = cardBgColor,
        elevation = cardElevation,
        shape = RoundedCornerShape(cardRoundedCorners),
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                vertical = 4.dp
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Box {
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)){
                        Image(painter = painterResource(id = R.drawable.bingo),
                            contentDescription ="IconList",
                            modifier = Modifier.padding(start = 10.dp))
                    }
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = card4.title,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 25.dp
                                )
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)
                    ) {
                        CardArrow(
                            degrees = arrowRotationDegree,
                            onClick = onCardArrowClick
                        )
                    }
                }
            }
            AcumuladosBingoExpand(expanded, viewModelPromotorNuevaVisita, navController)
        }
    }
}

@ExperimentalAnimationApi
@Composable
fun AcumuladosBingoExpand(
    expanded: Boolean = true,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    navController: NavController
) {
    AnimatedVisibility(
        visible = expanded,
        enter = enterExpand + enterFadeIn,
        exit = exitCollapse + exitFadeOut
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(8.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()) {
                Column(modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)) {

                    val mCalendar = Calendar.getInstance()
                    val mHour = mCalendar[Calendar.HOUR_OF_DAY]
                    val mMinute = mCalendar[Calendar.MINUTE]
                    val mContext = LocalContext.current
                    val mTimePickerDialogInicio = TimePickerDialog(
                        mContext,
                        {_, mHour : Int, mMinute: Int ->
                            viewModelPromotorNuevaVisita.hora_inicio_TEXT.value = "$mHour:00 hrs"
                            viewModelPromotorNuevaVisita.hora_inicio.value = mHour
                        }, mHour, mMinute, true
                    )
                    val mTimePickerDialogFin = TimePickerDialog(
                        mContext,
                        {_, mHour : Int, mMinute: Int ->
                            viewModelPromotorNuevaVisita.hora_fin_TEXT.value = "$mHour:00 hrs"
                            viewModelPromotorNuevaVisita.hora_fin.value = mHour
                        }, mHour, mMinute, true
                    )
                    var expanded by remember { mutableStateOf(false) }
                    var textfieldSize by remember { mutableStateOf(Size.Zero) }
                    val icon =
                        if (expanded)
                            Icons.Filled.KeyboardArrowUp
                        else
                            Icons.Filled.KeyboardArrowDown
                    val focusManager = LocalFocusManager.current
                    Text(text = "Proveedores",
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(bottom = 10.dp),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 19.sp)
                    OutlinedTextField(
                        enabled = false,
                        value = viewModelPromotorNuevaVisita.proveedor_acumulados.value,
                        onValueChange = { },
                        keyboardOptions = KeyboardOptions.Default.copy(
                            keyboardType = KeyboardType.Ascii,
                            imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Down) }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .onGloballyPositioned { coordinates ->
                                textfieldSize = coordinates.size.toSize()
                            }
                            .clickable {
                                navController.navigate(route = Destination.Dialog.route)
                                alertProveedorAcumulados.value=true
                            },
                        label = { Text("Seleccionar Provedor") },
                        trailingIcon = {
                            Icon(icon,"contentDescription",
                                Modifier.clickable {
                                    navController.navigate(route = Destination.Dialog.route)
                                    alertProveedorAcumulados.value=true
                                }
                            )
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth()){
                        OutlinedTextField(
                            value = viewModelPromotorNuevaVisita.inicio.value,
                            onValueChange = {
                                viewModelPromotorNuevaVisita.inicio.value = it
                                if(viewModelPromotorNuevaVisita.getValidationSum(viewModelPromotorNuevaVisita.inicio.value)){
                                    viewModelPromotorNuevaVisita.resta.value = viewModelPromotorNuevaVisita.getResta(viewModelPromotorNuevaVisita.inicio.value,viewModelPromotorNuevaVisita.fin.value).toString()
                                }
                            },
                            label = { Text("Inicio") },
                            modifier = Modifier.fillMaxWidth(.5f),
                            keyboardOptions = KeyboardOptions.Default.copy(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Right) }
                            ),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.MonetizationOn,
                                    contentDescription = "Precio Inicio"
                                )
                            }
                        )
                        Spacer(Modifier.width(5.dp))
                        OutlinedTextField(
                            value = viewModelPromotorNuevaVisita.fin.value,
                            onValueChange = {
                                viewModelPromotorNuevaVisita.fin.value = it
                                if(viewModelPromotorNuevaVisita.getValidationSum(viewModelPromotorNuevaVisita.fin.value)){
                                    viewModelPromotorNuevaVisita.resta.value = viewModelPromotorNuevaVisita.getResta(viewModelPromotorNuevaVisita.inicio.value,viewModelPromotorNuevaVisita.fin.value).toString()
                                }
                            },
                            label = { Text("Fin") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions.Default.copy(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next),
                            keyboardActions = KeyboardActions(
                                onNext = { focusManager.moveFocus(FocusDirection.Down) },
                            ),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.MonetizationOn,
                                    contentDescription = "Precio Inicio"
                                )
                            }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(text = "Diferencia",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row (modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.MonetizationOn, "Diferencia")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.resta.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = viewModelPromotorNuevaVisita.evento.value,
                        onValueChange = { viewModelPromotorNuevaVisita.evento.value = it },
                        label = { Text("Evento") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions.Default.copy(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Down) }
                        ),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Event,
                                contentDescription = "Precio Inicio"
                            )
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Hora Inicio",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Row (modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { mTimePickerDialogInicio.show() }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, "Hora Inicio")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.hora_inicio_TEXT.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Hora Fin",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp)
                    Spacer(Modifier.height(10.dp))
                    Row (modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { mTimePickerDialogFin.show() }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, "Hora Fin")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.hora_fin_TEXT.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = viewModelPromotorNuevaVisita.premio.value,
                        onValueChange = {  viewModelPromotorNuevaVisita.premio.value = it  },
                        label = { Text("Premio") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(
                            onNext = { focusManager.moveFocus(FocusDirection.Right) }
                        ),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.MonetizationOn,
                                contentDescription = "Precio Inicio"
                            )
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModelPromotorNuevaVisita.addAcumuladosBingo()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp),
                        elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                        shape = RoundedCornerShape(10),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = colorResource(id = R.color.reds)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Precio Inicio",
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    viewModelPromotorNuevaVisita.dataAcumuladosBingo.forEach { item ->
                        Card(modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.SnippetFolder, "Diferencia")
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 20.dp)
                                ) {
                                    Text(
                                        text = "Provedor: ${item.proveedor!!.nombre} \nAcumulado Inicio: $ ${item.inicio} \nAcumulado Fin: $ ${item.fin}",
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                        modifier = Modifier.padding(vertical = 15.dp, horizontal = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
