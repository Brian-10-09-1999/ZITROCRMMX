package com.example.zitrocrm.screens.salas.JuegosNuevosBingo

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.zitrocrm.R
import com.example.zitrocrm.ui.theme.blackdark
import com.example.zitrocrm.ui.theme.reds
import com.example.zitrocrm.repository.SharedPrefence

@Preview
@Composable
fun JuegosNuevosBingoScreens(
    //navController: NavController,
){
    val datastore = SharedPrefence(LocalContext.current)
    val cliente = ""+datastore.getCliente().toString()
    val region = ""+datastore.getRegion().toString()
    val sala = ""+datastore.getSala().toString()
    Scaffold(
        topBar = {
            TopAppBar(
                elevation = 0.dp,
                modifier = Modifier.height(70.dp),
                title = {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier
                            .align(alignment = Alignment.CenterStart)
                            .padding(start = 35.dp)) {
                            Text(text = "FILTROS DE BUSQUEDA ", fontSize = 9.sp, color = Color.White)
                            Text(text = "Cliente: "+cliente, fontSize = 7.sp, color = Color.White)
                            Text(text = "Region: "+region, fontSize = 7.sp, color = Color.White)
                            Text(text = "Sala: "+sala, fontSize = 7.sp, color = Color.White)
                        }
                        Image(
                            painter = painterResource(R.drawable.back_button),
                            contentDescription = "",
                            modifier = Modifier
                                .clickable {
                                    //navController.popBackStack()
                                }
                                .align(Alignment.CenterStart)
                                .size(29.dp)
                        )
                        Image(
                            painter = painterResource(R.drawable.crm_logo),
                            contentDescription = "",
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(5.dp)
                        )
                    }
                },
                backgroundColor = reds,
            )
        },
    ) {
        ContentJuegosNuevosBingo()
    }
}

@Composable
fun ContentJuegosNuevosBingo (
){
    Column(
        modifier = Modifier
            .padding(start = 10.dp,end = 10.dp, bottom = 10.dp)
            .verticalScroll(state = ScrollState(1))
    ) {
        Column(
            modifier = Modifier
                .padding(bottom = 10.dp, top = 10.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(blackdark)
                .fillMaxWidth()
                .size(80.dp),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        )
        {
            Image(
                painter = painterResource(R.drawable.nav_maquinas_icon),
                contentDescription = "",
                modifier = Modifier
                    .padding(top = 5.dp)
                    .size(50.dp)
            )
            Text(
                text = "Juegos Nuevos Bingo",
                style = MaterialTheme.typography.subtitle1,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 3.dp),
                color = Color.White
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                Spacer(modifier = Modifier.padding(5.dp))
                Row(modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { /*mDatePickerDialog.show()*/ }
                    .fillMaxWidth()
                    .background(color = blackdark)
                    .padding(horizontal = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Person, "User")
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)
                    ) {
                        Text(
                            text = "Nombre: Luis Gomez"/*viewModelPromotorNuevaVisita.fecha_visita.value*/,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.padding(vertical = 17.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.padding(5.dp))
                OutlinedTextField(
                    value = "METRONIA" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                    onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                    modifier = Modifier
                        .fillMaxWidth(),
                    label = { Text("Proveedor") },
                    trailingIcon = {
                        Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                            Modifier.clickable {
                                //alertObjetivoSemanal.value=true
                                //navController.navigate(route = Destination.Dialog.route)
                            }
                        )
                    }
                )
                Spacer(modifier = Modifier.padding(5.dp))
                OutlinedTextField(
                    value = "GIRA GIRA" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                    onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                    label = { Text("Nombre Juego") },
                    modifier = Modifier
                        .fillMaxWidth(),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Games,
                            contentDescription = "Botón para elegir fecha"
                        )
                    }
                )
                Spacer(modifier = Modifier.padding(5.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "10" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                        label = { Text("No. de Cartones") },
                        modifier = Modifier
                            .fillMaxWidth(.5f),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Pin,
                                contentDescription = "Botón para elegir fecha"
                            )
                        }
                    )
                    Spacer(modifier = Modifier.padding(5.dp))
                    OutlinedTextField(
                        value = "3x4" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                        modifier = Modifier
                            .fillMaxWidth(),
                        label = { Text("Tipo de Cartones") },
                        trailingIcon = {
                            Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                                Modifier.clickable {
                                    //alertObjetivoSemanal.value=true
                                    //navController.navigate(route = Destination.Dialog.route)
                                }
                            )
                        }
                    )
                }
                Spacer(modifier = Modifier.padding(5.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "10" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                        label = { Text("Figura en la Tabla de Premios") },
                        modifier = Modifier
                            .fillMaxWidth(.5f),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = "Botón para elegir fecha"
                            )
                        }
                    )
                    Spacer(modifier = Modifier.padding(5.dp))
                    OutlinedTextField(
                        value = "13" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                        label = { Text("Bolas Sorteadas") },
                        modifier = Modifier
                            .fillMaxWidth(),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = "Botón para elegir fecha"
                            )
                        }
                    )
                }
                Spacer(modifier = Modifier.padding(5.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "26" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                        label = { Text("Bolas Extras") },
                        modifier = Modifier
                            .fillMaxWidth(.5f),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = "Botón para elegir fecha"
                            )
                        }
                    )
                    Spacer(modifier = Modifier.padding(5.dp))
                    OutlinedTextField(
                        value = "17" /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoGeneralidfk_visita.value = it*/ },
                        label = { Text("Acceso a Bonus") },
                        modifier = Modifier
                            .fillMaxWidth(),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.AccountBalanceWallet,
                                contentDescription = "Botón para elegir fecha"
                            )
                        }
                    )
                }
                Spacer(modifier = Modifier.padding(5.dp))
                Text(
                    text = "Comodín"/*viewModelPromotorNuevaVisita.fecha_visita.value*/,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.padding(5.dp))
                Row(modifier = Modifier.padding(5.dp)) {
                    Row(modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { /*mDatePickerDialog.show()*/ }
                        .fillMaxWidth(.5f)
                        .background(color = blackdark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = true, onCheckedChange = {})
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 20.dp)
                        ) {
                            Text(
                                text = "Si"/*viewModelPromotorNuevaVisita.fecha_visita.value*/,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(vertical = 14.dp, horizontal = 5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.padding(5.dp))
                    Row(modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { /*mDatePickerDialog.show()*/ }
                        .fillMaxWidth(1f)
                        .background(color = blackdark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = true, onCheckedChange = {})
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 20.dp)
                        ) {
                            Text(
                                text = "No"/*viewModelPromotorNuevaVisita.fecha_visita.value*/,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(vertical = 14.dp, horizontal = 5.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.padding(5.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                )
                {
                    OutlinedTextField(
                        value = "1c" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                        modifier = Modifier
                            .fillMaxWidth(.5f),
                        label = { Text("Denominación Mín") },
                        trailingIcon = {
                            Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                                Modifier.clickable {
                                    //alertObjetivoSemanal.value=true
                                    //navController.navigate(route = Destination.Dialog.route)
                                }
                            )
                        }
                    )
                    Spacer(modifier = Modifier.padding(5.dp))
                    OutlinedTextField(
                        value = "$10" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                        onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                        modifier = Modifier
                            .fillMaxWidth(),
                        label = { Text("Denominación Máx") },
                        trailingIcon = {
                            Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                                Modifier.clickable {
                                    //alertObjetivoSemanal.value=true
                                    //navController.navigate(route = Destination.Dialog.route)
                                }
                            )
                        }
                    )
                }
                Spacer(modifier = Modifier.padding(5.dp))
                OutlinedTextField(
                    value = "Alta" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                    onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                    modifier = Modifier
                        .fillMaxWidth(),
                    label = { Text("Perfil") },
                    trailingIcon = {
                        Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                            Modifier.clickable {
                                //alertObjetivoSemanal.value=true
                                //navController.navigate(route = Destination.Dialog.route)
                            }
                        )
                    }
                )
                Spacer(modifier = Modifier.padding(5.dp))
                OutlinedTextField(
                    value = "Power" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                    onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                    modifier = Modifier
                        .fillMaxWidth(),
                    label = { Text("Compite con Familia") },
                    trailingIcon = {
                        Icon(Icons.Filled.KeyboardArrowUp, "contentDescription",
                            Modifier.clickable {
                                //alertObjetivoSemanal.value=true
                                //navController.navigate(route = Destination.Dialog.route)
                            }
                        )
                    }
                )
                Spacer(modifier = Modifier.padding(5.dp))
                OutlinedTextField(
                    enabled = false,
                    value = "Sap" /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value*/,
                    onValueChange = { /*viewModelPromotorNuevaVisita.objetivoSemanal_visita.value */ },
                    modifier = Modifier
                        .fillMaxWidth(),
                    label = { Text("Progresivos") },
                    leadingIcon = {
                        Icon(Icons.Filled.MarkChatRead, "contentDescription",
                            Modifier.clickable {
                                //alertObjetivoSemanal.value=true
                                //navController.navigate(route = Destination.Dialog.route)
                            }
                        )
                    }
                )
                Spacer(modifier = Modifier.padding(10.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp)
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            text = "Seleccion Simple",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            text = "Slots",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            text = "Al mejor de 3",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            text = "Seleccion Simple",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            text = "Partida gratis de niveles",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                        Text(
                            text = "Otro",
                            Modifier
                                .clickable { }
                                .fillMaxWidth()
                                .padding(vertical = 5.dp, horizontal = 2.dp),
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}