package com.example.zitrocrm.network.models_dto.DetalleOcupacionDto

import com.google.gson.annotations.SerializedName


data class Visita (

  @SerializedName("conclusion"            ) var conclusion            : String?  = null,
  @SerializedName("fecha"                 ) var fecha                 : Fecha?   = null,
  @SerializedName("horaEntrada"           ) var horaEntrada           : Int?     = null,
  @SerializedName("horaSalida"            ) var horaSalida            : Int?     = null,
  @SerializedName("objetivo"              ) var objetivo              : Int?     = null,
  @SerializedName("objetivoSemanal"       ) var objetivoSemanal       : String?  = null,
  @SerializedName("observacionesGenerales") var observacionesGenerales: String?  = null,
  @SerializedName("porque"                ) var porque                : String?  = null,
  @SerializedName("propuestas"            ) var propuestas            : String?  = null,
  @SerializedName("queHacer"              ) var queHacer              : String?  = null,
  @SerializedName("salaid"                ) var salaid                : Int?     = null,
  @SerializedName("seLogro"               ) var seLogro               : Boolean? = null,
  @SerializedName("tipo"                  ) var tipo                  : Int?     = null,

  )

data class Fecha (
  @SerializedName("day" ) var day        : Int?  = null,
  @SerializedName("month" ) var month    : Int?  = null,
  @SerializedName("year" ) var year      : Int?  = null,
  )