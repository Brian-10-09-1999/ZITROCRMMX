package com.example.zitrocrm.screens.salas.PromotorNuevaVisita

import android.util.Log
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.zitrocrm.network.models_dto.CheckTimeModel
import com.example.zitrocrm.network.models_dto.DetalleOcupacionDto.*
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.Competencia.CompetenciaArray
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.FoliosTecnicos.rows
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.JuegosFilter.Juegos
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.JuegosFilter.SubJuegosArray
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.ObjSemanalFilter.Message
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.ProveedorFilter.Rows
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.SampleData
import com.example.zitrocrm.network.repository.RetrofitHelper
import com.example.zitrocrm.screens.login.components.progressBar
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class PromotorNuevaVisitaViewModel @Inject constructor(

) : ViewModel() {

    val sap2 = mutableStateOf(false)
    val lap2 = mutableStateOf(false)
    val fumar2 = mutableStateOf(false)
    val nofumar2 = mutableStateOf(false)

    var positivo = mutableStateOf(false)
    var negativo = mutableStateOf(false)
    var positivo2 = mutableStateOf(false)
    var negativo2 = mutableStateOf(false)
    var positivo3 = mutableStateOf(false)
    var negativo3 = mutableStateOf(false)

    var statecheckBingo = mutableStateOf(false)
    val objetivoSemanal : MutableList<Message> = arrayListOf()
    val juegosFilter : MutableList<Juegos> = arrayListOf()
    val data : MutableList<Ocupacion> = arrayListOf()
    val dataSlots : MutableList<OcupacionSlots> = arrayListOf()
    val dataHorariosDeleteAlertDialog : MutableState<Horarios> = mutableStateOf(Horarios())

    val foliostecnicossalas : MutableList<rows> = arrayListOf()

    val dataTime : MutableList<CheckTimeModel> = arrayListOf()
    val inicio_visita_TEXT = mutableStateOf("Selecciona Hora")
    val fin_visita_TEXT = mutableStateOf("Selecciona Hora")
    val hora_inicio_TEXT = mutableStateOf("Selecciona Hora")
    val hora_fin_TEXT = mutableStateOf("Selecciona Hora")
    /**BINGO 2  SLOTS 1 **/
    val objetivoIdSelecc = mutableStateOf(0)
    /**VISITA PROMOTORES**/
    var fecha_visita =  mutableStateOf("Seleccionar Fecha")
    var mYear =  mutableStateOf(0)
    var Month =  mutableStateOf(0)
    var mDayOfMonth =  mutableStateOf(0)
    var inicio_visita =  mutableStateOf(0)
    var fin_visita = mutableStateOf(0)
    val objetivoSemanal_visita = mutableStateOf("Selecciona el Objetivo Semanal")
    var objetivoGeneralidfk_visita = mutableStateOf("")
    var tipoJuego_visita = mutableStateOf(0)
    var seLogro_visita =  mutableStateOf(false)
    var por_que_objetivo = mutableStateOf("")
    var propuestas_visita =  mutableStateOf("")
    var conclucion_visita =  mutableStateOf("")
    var observaciones_visita =  mutableStateOf("")
    /**OBJETIVO DE LA VISITA**/
    var queHacer_visita = mutableStateOf("")
    /**promotor**/
    /**DETALLE DE OCUPACION**/
    var proveedor_Ocupacion = mutableStateOf("")
    var proveedor_ID_Ocupacion = mutableStateOf(0)
    var idBingoSlots = mutableStateOf(0)
    var JuegoBingoSlots = mutableStateOf("")
    val totalSlotsOcupacion =  mutableStateOf("")
    val maquinas1_Bingo =  mutableStateOf("")
    val maquinasLt1_Bingo =  mutableStateOf("")
    val total_Bingo = mutableStateOf("")
    val maquinasSlots =  mutableStateOf("")
    val unidadOcupacion = mutableStateOf("")

    val dataProvedorOcupacion : MutableList<Ocupacion> = arrayListOf()
    val dataProvedorOcupacionSlots : MutableList<OcupacionSlots> = arrayListOf()
    val proveedorOcupacion : MutableList<Rows> = arrayListOf()


    /**ACUMULADOS BINGO**/
    var id_proveedor_acumulados = mutableStateOf(0)
    var inicio = mutableStateOf("")
    var fin = mutableStateOf("")
    var evento = mutableStateOf("")
    var premio = mutableStateOf("")
    var hora_fin = mutableStateOf(0)
    var hora_inicio = mutableStateOf(0)
    var proveedor_acumulados = mutableStateOf("")
    /****/var resta = mutableStateOf("")
    val dataAcumuladosBingo: MutableList<Acumulados> = arrayListOf()
    /**LO MAS JUGADO ZITRO Y COMPETENCIA**/
    var id_proveedor_lo_mas_jugado = mutableStateOf(0)
    var proveedor_lo_mas_jugado = mutableStateOf("")
    var producto_mas_jugado = mutableStateOf("")
    var id_producto_mas_jugado = mutableStateOf(0)
    var tiro_minimo =  mutableStateOf("")
    var tiro_maximo =  mutableStateOf("")
    var tiro_promedio =  mutableStateOf("")
    var apuestas_promedio =  mutableStateOf("")
    var promedio_ocupacion =  mutableStateOf("")
    var fumar = mutableStateOf(0)
    var no_fumar = mutableStateOf(0)

    val dataLoMasJugadoZitroCompMODEL : MutableList<MasJugado> = arrayListOf(MasJugado())

    val dataLoMasJugadoZitroZomp : MutableList<MasJugado> = arrayListOf()
    val Zonaid: MutableList<Zona> = arrayListOf()
    val Progresivos: MutableList<Progresivos> = arrayListOf()
    /**COMENTARIOS GENERALES JUGADORES**/
    var calificacion_comentarios =  mutableStateOf(false)
    var juego_comentarios =  mutableStateOf("")
    var id_juego_comentarios =  mutableStateOf(0)
    var perfil_comentarios =  mutableStateOf("")
    var id_perfil = mutableStateOf(0)
    var procedencia_comentarios =  mutableStateOf("")
    var ingresos_comentarios =  mutableStateOf("")
    var comentarios_jugadores =  mutableStateOf("")
    val dataComentariosGeneralesJugadores : MutableList<Comentarios> = arrayListOf()
    /**COMENTARIOS SONIDOS NUESTRAS MAQUINAS, ZITRO COMPETENCIA**/
    var calificacion_sonido =  mutableStateOf(true)
    var provedor_sonido_comentarios =  mutableStateOf("")
    var id_provedor_sonido_comentarios =  mutableStateOf(0)
    var observaciones_sonido =  mutableStateOf("")
    /**OBSERVACIONES COMPETENCIA**/
    var calificacion_competencia =   mutableStateOf(false)
    var provedor_competencia =  mutableStateOf("")
    var id_provedor_competencia =  mutableStateOf(0)
    var observaciones_competencia =  mutableStateOf("")
    val dataObservacionesCompetencia : MutableList<ObservacionesCompetencia> = arrayListOf()
    val addSonido : MutableList<Sonido> = arrayListOf()

    fun checksZonaId (){
        if(fumar2.value){
            addZonaId(1,"Fumar")
        }
        if(nofumar2.value){
            addZonaId(2,"No fumar")
        }
        if(sap2.value){
            addSapLap(1,"Sap")
        }
        if(lap2.value){
            addSapLap(2,"Lap")
        }
    }

    fun addZonaId (zonaid:Int,zona:String){
        Zonaid.filter { it.id == zonaid.toString() }.forEach {
            Zonaid.remove(Zona(id = zonaid.toString(), zona = zona))
        }
        Zonaid.add(Zona(zonaid.toString(),zona))
    }
    fun addSapLap (id:Int,progresivos:String){
        Progresivos.filter { it.id == id.toString() }.forEach {
            Progresivos.remove(Progresivos(id = id.toString(), progresivos = progresivos))
        }
        Progresivos.add(Progresivos(id.toString(),progresivos))
    }

    fun addItemObjetivo(id:Int,objetivo:String){
        objetivoSemanal_visita.value = objetivo
        objetivoIdSelecc.value = id
    }
    fun addObjetivoSemanal(id:Int, objetivo:String){
        objetivoSemanal.filter { it.id == id }.forEach {
            objetivoSemanal.remove(Message(id = id,objetivo = objetivo))
        }
        objetivoSemanal.add(Message(id = id,objetivo = objetivo))
    }
    fun addJuegos (id:Int, nombre: String){
        juegosFilter.filter { it.id == id }.forEach {
            juegosFilter.remove(Juegos(id = id,nombre = nombre))
        }
        juegosFilter.add(Juegos(id = id,nombre = nombre))
    }

    fun addProveedor(id: Int, nombre: String){
        proveedorOcupacion.filter { it.id == id }.forEach{
            proveedorOcupacion.remove(Rows(id,nombre))
        }
        proveedorOcupacion.add(Rows(id,nombre))
    }

    fun itemhorarioArray(horario:Int?, maquinas1 : Int?, maquinasLt1 : Int?){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                data.find { it.horario == horario }?.ocupacionMaquinas1 = maquinas1
                data.find { it.horario == horario }?.ocupacionMaquinaslt1 = maquinasLt1
                data.find { it.horario == horario }?.proveedoridfk = proveedor_ID_Ocupacion.value
                data.find { it.horario == horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                data.find { it.horario == horario }?.maquinasLt1 = maquinasLt1_Bingo.value.toInt()
                data.find { it.horario == horario }?.juegoidfk = idBingoSlots.value
                data.find { it.horario == horario }?.proveedor = proveedor_Ocupacion.value

                dataSlots.find { it.horario == horario }?.ocupacionMaquinas1 = maquinas1
                dataSlots.find { it.horario == horario }?.proveedoridfk = proveedor_ID_Ocupacion.value
                dataSlots.find { it.horario == horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                dataSlots.find { it.horario == horario }?.juegoidfk = idBingoSlots.value
                dataSlots.find { it.horario == horario }?.proveedor = proveedor_Ocupacion.value

                //Log.d("find", " EDIT VALUE"+ data.toString())
            }catch (e: Exception) {
                Log.d("Exception", "ARRAY HORARIOS", e)
            }
        }
    }
    fun addFoliosTecnicosSalas(
        nombre:String,
        Seq:String,
        count:Int,
        descripcionFalla:String,
        estatus:String,
        fecha :String,
        gabinete : String,
        juego : String,
        licencia : String,
        medio : String,
        motivo : String,
        numeroFolio : Int,
        origen : String,
        serie : String
    ){
        foliostecnicossalas.add(rows(
            nombre,
            Seq,
            count,
            descripcionFalla,
            estatus,
            fecha,
            gabinete,
            juego,
            licencia,
            medio,
            motivo,
            numeroFolio,
            origen,
            serie
        ))
    }

    fun getFoliosTecnicos (token : String, sala : Int, cliente : Int){
        foliostecnicossalas.clear()
        viewModelScope.launch(Dispatchers.IO) {
            val authService = RetrofitHelper.getAuthService()
            try {
                val responseService = authService.getFoliosTecnicosSalas(token, sala,cliente)
                if (responseService.isSuccessful) {
                    responseService.body()!!.rows.forEach{ respose ->
                        addFoliosTecnicosSalas(
                            respose.nombre.toString(),
                            respose.Seq.toString(),
                            respose.count!!.toInt(),
                            respose.descripcionFalla.toString(),
                            respose.estatus.toString(),
                            respose.fecha.toString(),
                            respose.gabinete.toString(),
                            respose.juego.toString(),
                            respose.licencia.toString(),
                            respose.medio.toString(),
                            respose.motivo.toString(),
                            respose.numeroFolio!!.toInt(),
                            respose.origen.toString(),
                            respose.serie.toString()
                        )
                    }
                }
            }catch (e: Exception) {
                Log.d("Exception", "GET FOLIOS TECNICOS", e)
            }
        }
    }

    val networkstate = mutableStateOf("")
    val networkstate_ID = mutableStateOf(0)
    fun postVisitaPromotoresSala (token:String, salaid : Int){
        viewModelScope.launch(Dispatchers.IO) {
            val authService = RetrofitHelper.getAuthService()
            if (statecheckBingo.value==false){
                try {
                    progressBar.value = true
                    val responseService = authService.postSalaVisitaPromotores(
                        token = token,
                        PromotorNuevaVisita(Visita(
                            conclusion = conclucion_visita.value,
                            fecha = Fecha(day = mDayOfMonth.value, month = Month.value, year = mYear.value),
                            horaEntrada = inicio_visita.value,
                            horaSalida = fin_visita.value,
                            objetivo = objetivoIdSelecc.value,
                            objetivoSemanal = objetivoGeneralidfk_visita.value,
                            observacionesGenerales = observaciones_visita.value,
                            porque = por_que_objetivo.value,
                            propuestas = propuestas_visita.value,
                            queHacer = queHacer_visita.value,
                            seLogro = seLogro_visita.value,
                            tipo = tipoJuego_visita.value,
                            salaid = salaid
                        ),
                            ocupacion = ArrayList<Ocupacion>(dataProvedorOcupacion),
                            acumulados = ArrayList<Acumulados>(dataAcumuladosBingo),
                            masJugado = ArrayList<MasJugado>(dataLoMasJugadoZitroZomp),
                            comentarios = ArrayList<Comentarios>(dataComentariosGeneralesJugadores),
                            comentariosSonido = ArrayList<Sonido>(addSonido),
                            observacionesCompetencia = ArrayList<ObservacionesCompetencia>(dataObservacionesCompetencia)
                        )
                    )
                    if (responseService.isSuccessful){
                        networkstate_ID.value = responseService.body()!!.message!!.id!!.toInt()
                        networkstate.value = responseService.body()!!.msg.toString()
                        alertDetalleSave.value = true
                    }else{
                        networkstate.value = responseService.body()!!.msg.toString()
                        alertDetalleSave.value = true
                        //Log.d("Else", "POST VISITA PROMOTORES")
                    }
                    progressBar.value = false
                } catch (e: Exception) {
                    networkstate.value = "O VERIFICA TU CONEXION"
                    alertDetalleSave.value = true
                    progressBar.value = false
                    Log.d("Exception", "POST VISITA PROMOTORES", e)
                }
            }else{
                try {
                    progressBar.value = true
                    val responseService = authService.postSalaVisitaPromotores(
                        token = token,
                        PromotorNuevaVisita(Visita(
                            conclusion = conclucion_visita.value,
                            fecha = Fecha(day = mDayOfMonth.value, month = Month.value, year = mYear.value),
                            horaEntrada = inicio_visita.value,
                            horaSalida = fin_visita.value,
                            objetivo = objetivoIdSelecc.value,
                            objetivoSemanal = objetivoGeneralidfk_visita.value,
                            observacionesGenerales = observaciones_visita.value,
                            porque = por_que_objetivo.value,
                            propuestas = propuestas_visita.value,
                            queHacer = queHacer_visita.value,
                            seLogro = seLogro_visita.value,
                            tipo = tipoJuego_visita.value,
                            salaid = salaid
                        ),
                            ocupacionSlots = ArrayList<OcupacionSlots>(dataProvedorOcupacionSlots),
                            acumulados = ArrayList<Acumulados>(dataAcumuladosBingo),
                            masJugado = ArrayList<MasJugado>(dataLoMasJugadoZitroZomp),
                            comentarios = ArrayList<Comentarios>(dataComentariosGeneralesJugadores),
                            comentariosSonido = ArrayList<Sonido>(addSonido),
                            observacionesCompetencia = ArrayList<ObservacionesCompetencia>(dataObservacionesCompetencia),
                        )
                    )
                    if (responseService.isSuccessful){
                        networkstate_ID.value = responseService.body()!!.message!!.id!!.toInt()
                        networkstate.value = responseService.body()!!.msg.toString()
                        alertDetalleSave.value = true
                    }else{
                        networkstate.value = responseService.body()!!.msg.toString()
                        alertDetalleSave.value = true
                        //Log.d("Else", "POST VISITA PROMOTORES")
                    }
                    progressBar.value = false
                } catch (e: Exception) {
                    networkstate.value = "O VERIFICA TU CONEXION"
                    alertDetalleSave.value = true
                    progressBar.value = false
                    Log.d("Exception", "POST VISITA PROMOTORES", e)
                }
            }
            if(networkstate_ID.value>0){
                cleanReport()
            }
        }
    }
    fun cleanReport(){
        conclucion_visita.value = ""
        objetivoIdSelecc.value = 0
        observaciones_visita.value = ""
        por_que_objetivo.value = ""
        propuestas_visita.value = ""
        queHacer_visita.value = ""
        seLogro_visita.value = false
        tipoJuego_visita.value = 0
        dataProvedorOcupacion.clear()
        dataProvedorOcupacionSlots.clear()
        dataAcumuladosBingo.clear()
        dataLoMasJugadoZitroZomp.clear()
        dataComentariosGeneralesJugadores.clear()
        addSonido.clear()
        dataObservacionesCompetencia.clear()
        alertDetalleSave.value = true
    }
    fun checkSwitchBingoSlots (token: String){
        if (statecheckBingo.value){
            val valueCheckBingoSlots = 1
            getObjetivoSemanal(token, valueCheckBingoSlots)
        }else{
            val valueCheckBingoSlots = 2
            getObjetivoSemanal(token, valueCheckBingoSlots)
        }
    }

    val librerias_ocupacion : MutableList<CompetenciaArray> = arrayListOf()

    val subjuegos_ocupacion : MutableList<SubJuegosArray> = arrayListOf()

    fun addLibreriasProveedores(id:Int, nombre:String, tipo : Int ){
        librerias_ocupacion.filter { it.id == id }.forEach {
            librerias_ocupacion.remove(CompetenciaArray(id = id,nombre = nombre,tipo = tipo))
        }
        librerias_ocupacion.add(CompetenciaArray(id = id,nombre = nombre,tipo = tipo))
    }

    fun addSubjuegosOcupacion(id:Int, nombre:String){
        subjuegos_ocupacion.filter { it.id == id }.forEach {
            subjuegos_ocupacion.remove(SubJuegosArray(id = id,nombre = nombre))
        }
        subjuegos_ocupacion.add(SubJuegosArray(id = id,nombre = nombre))
    }

    fun getJuegosOcupacion(token:String,juegoid:Int){
        viewModelScope.launch(Dispatchers.IO){
            val authService = RetrofitHelper.getAuthService()
            try{
                progressBar.value = true
                val responseService = authService.getSubJuegosOcupacion(token,juegoid)
                if (responseService.ok!!) {
                    responseService.juegos.forEach{item->
                        addSubjuegosOcupacion(item.id!!,item.nombre!!)
                    }
                    Log.d("succcess", "JuegosOcupacion"+responseService.juegos )
                }
                progressBar.value = false
            }catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER OBJETIVO FAIL", e)
            }
        }
    }

    fun getLibreriaCompetencia(token : String, proveedorid:Int){
        viewModelScope.launch(Dispatchers.IO){
            librerias_ocupacion.clear()
            val authService = RetrofitHelper.getAuthService()
            try{
                progressBar.value = true
                val responseService = authService.getSalasLibrerias(token,idBingoSlots.value,proveedorid)
                if (responseService.ok!!) {
                    responseService.librerias.forEach{ item ->
                        addLibreriasProveedores(item.id!!,item.nombre!!,item.tipo!!)
                    }
                    Log.d("succcess", "LibreriaCompetencia"+responseService.librerias )
                }
                progressBar.value = false
            }catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER OBJETIVO FAIL", e)
            }
        }
    }
    fun getObjetivoSemanal (token : String, tipoId : Int){
        objetivoSemanal.clear()
        juegosFilter.clear()
        viewModelScope.launch(Dispatchers.IO) {
            /**FILTER OBJETIVO SEMANAL**/
            val authService = RetrofitHelper.getAuthService()
            try {
                progressBar.value = true
                val responseService = authService.getObjSemanal(token, tipoId)
                if (responseService.ok!!) {
                    responseService.message.forEach { Response ->
                        addObjetivoSemanal(
                            id = Response.id!!.toInt(),
                            objetivo = Response.objetivo.toString()
                        )
                    }
                } else {
                    Log.d("filter", "ELSE OBJETIVO")
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER OBJETIVO FAIL", e)
            }
            /**FILTER JUEGOS BINGO SLOTS**/
            try {
                progressBar.value = true
                val responseService = authService.getJuegosZitro(token, tipoId)
                if (responseService.isSuccessful) {
                    responseService.body()!!.juegos.forEach { Respose ->
                        addJuegos(
                            id = Respose.id!!.toInt(),
                            nombre = Respose.nombre.toString()
                        )
                        //Log.d("filter", "JUEGOS"+Respose)
                    }

                } else{
                }
                progressBar.value = false
            }catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER OBJETIVO FAIL", e)
            }
            /**PROVEEDORES**/
            try {
                progressBar.value = true
                val responseService = authService.getProveedores(token)
                responseService.body()!!.rows.forEach{ Items ->
                    addProveedor(Items.id!!.toInt(),Items.nombre.toString())
                    //Log.d("FILTER", "PROVEEDORES"+ Items.nombre.toString())
                }
                if (responseService.isSuccessful){

                }else{
                    Log.d("FILTER", "Ya valioaaaiuda")
                }
                progressBar.value = false
            } catch (e: Exception) {
                progressBar.value = false
                Log.d("Exception", "FILTER SALAS FAIL", e)
            }
            if (statecheckBingo.value==false){
                idBingoSlots.value = tipoId
                tipoJuego_visita.value = tipoId
                JuegoBingoSlots.value = "Bingo"
            }else if(statecheckBingo.value==true){
                idBingoSlots.value = tipoId
                tipoJuego_visita.value = tipoId
                JuegoBingoSlots.value = "Slots"
            }
        }
    }

    fun addinfoArrayOcupacion(token:String,horario: Int?,){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                data.find { it.horario == horario }?.proveedoridfk = proveedor_ID_Ocupacion.value
                data.find { it.horario == horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                data.find { it.horario == horario }?.maquinasLt1 = maquinasLt1_Bingo.value.toInt()
                data.find { it.horario == horario }?.juegoidfk = idBingoSlots.value
                data.find { it.horario == horario }?.proveedor = proveedor_Ocupacion.value

                dataSlots.find { it.horario == horario }?.proveedoridfk = proveedor_ID_Ocupacion.value
                dataSlots.find { it.horario == horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                dataSlots.find { it.horario == horario }?.juegoidfk = idBingoSlots.value
                dataSlots.find { it.horario == horario }?.proveedor = proveedor_Ocupacion.value

                getLibreriaCompetencia(token,proveedor_ID_Ocupacion.value)

            }catch (e: Exception) {
                Log.d("Exception", "ARRAY HORARIOS", e)
            }
        }
    }

    fun selectProveedorOcupacion (token: String, id:Int, nombre:String,){
        alertProveedorOcupacion.value = false
        proveedor_Ocupacion.value = nombre
        proveedor_ID_Ocupacion.value = id
        viewModelScope.launch(Dispatchers.IO) {
            try{
                data.forEach { label2 ->
                    data.find { it.horario == label2.horario }?.proveedoridfk = id
                    data.find { it.horario == label2.horario }?.proveedor = nombre
                    data.find { it.horario == label2.horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                    data.find { it.horario == label2.horario }?.maquinasLt1 = maquinasLt1_Bingo.value.toInt()
                    data.find { it.horario == label2.horario }?.juegoidfk = idBingoSlots.value
                }
                dataSlots.forEach { label2 ->
                    dataSlots.find { it.horario == label2.horario }?.proveedoridfk = id
                    dataSlots.find { it.horario == label2.horario }?.maquinas1 = maquinas1_Bingo.value.toInt()
                    dataSlots.find { it.horario == label2.horario }?.juegoidfk = idBingoSlots.value
                    dataSlots.find { it.horario == label2.horario }?.proveedor = nombre
                }
                getLibreriaCompetencia(token,id)
            }catch (e: Exception) {
                Log.d("Exception", "FAIL", e)
            }
        }
    }

    fun selectProveedorAcumulados (id:Int, nombre:String,){
        alertProveedorAcumulados.value = false
        proveedor_acumulados.value = nombre
        id_proveedor_acumulados.value = id
    }
    fun selectProveedorLoMasJugado (id:Int, nombre:String,){
        alertProveedorLoMasJugado.value = false
        proveedor_lo_mas_jugado.value = nombre
        id_proveedor_lo_mas_jugado.value = id
    }
    fun selectProveedorSonido (id:Int, nombre:String,){
        alertProveedorSonido.value = false
        provedor_sonido_comentarios.value = nombre
        id_provedor_sonido_comentarios.value = id
    }
    fun selectProvedorObservaciones (id:Int, nombre:String,){
        alertObservacionesCompetecia.value = false
        provedor_competencia.value = nombre
        id_provedor_competencia.value = id
    }
    fun selectJuegoMasJugado (id: Int, nombre: String){
        alertJuegosFilter.value =  false
        producto_mas_jugado.value = nombre
        id_producto_mas_jugado.value = id
    }

    val libreria_ocupacion = mutableStateOf("")
    val id_libreria_ocupacion = mutableStateOf(0)
    val tipo_libreria_ocupacion = mutableStateOf(0)

    fun selectLibreriaOcupacion (id: Int, nombre: String, tipo : Int){
        alertLibreriaOcupacion.value =  false
        alertLibreriaOcupacionSlots.value = false
        libreria_ocupacion.value = nombre
        id_libreria_ocupacion.value = id
        tipo_libreria_ocupacion.value = tipo
    }
    fun selectJuegoComentGeneralesJugadores (id: Int, nombre: String){
        alertJuegosComentariosJugadores.value =  false
        juego_comentarios.value = nombre
        id_juego_comentarios.value = id
    }

    fun getValidationSum(string: String): Boolean{
        val component = "[0-9]{1,9}"
        return component.toRegex().matches(string)
    }

    fun getSum(a:String, b:String): Int{
        var A = ""
        var B = ""
        if(getValidationSum(a)){
            A = a
        }
        if(getValidationSum(b)){
            B = b
        }
        if(A==""){
            A="0"
        }
        if(B==""){
            B="0"
        }
        return A.toInt()+B.toInt()
    }

    fun getResta(a:String, b:String): Int{
        var A = ""
        var B = ""
        if(getValidationSum(a)){
            A = a
        }
        if(getValidationSum(b)){
            B = b
        }
        if(A==""){
            A="0"
        }
        if(B==""){
            B="0"
        }
        return B.toInt()-A.toInt()
    }


    fun getPorcentaje(a: String, b:String): Double{
        var A = ""
        var B = ""
        if(getValidationSum(a)){
            A = a
        }
        if(getValidationSum(b)){
            B = b
        }
        if(A==""){
            A="0"
        }
        if(B==""){
            B="0"
        }
        return A.toInt()*100/B.toDouble()
    }

    fun sumOcupacionSlots(){
        totalSlotsOcupacion.value = maquinasSlots.value
    }

    fun addLoMasJugadoZitroComp (){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                dataLoMasJugadoZitroZomp.add(
                    MasJugado(
                    proveedor = ID(id_proveedor_lo_mas_jugado.value,proveedor_lo_mas_jugado.value),
                    tiroMinimo = tiro_minimo.value.toInt(),
                        tiroMaximo = tiro_maximo.value.toInt(),
                        tiroPromedio = tiro_promedio.value.toInt(),
                        apuestasPromedio = apuestas_promedio.value.toInt(),
                        promedioOcupacion = promedio_ocupacion.value.toInt(),
                        zona = ArrayList<Zona>(Zonaid),
                        progresivos = ArrayList<Progresivos>(Progresivos),
                        juego = ID(id_producto_mas_jugado.value,producto_mas_jugado.value),
                        unidadOcupacion = unidadOcupacion.value
                    )
                )
                Log.d("SUCCESS", "LO MAS JUGADO ARRAY"+ dataLoMasJugadoZitroZomp)
                id_proveedor_lo_mas_jugado.value = 0
                proveedor_lo_mas_jugado.value = ""
                tiro_minimo.value = ""
                tiro_maximo.value = ""
                tiro_promedio.value = ""
                apuestas_promedio.value = ""
                promedio_ocupacion.value = ""
                Zonaid.clear()
                Progresivos.clear()
                proveedor_lo_mas_jugado.value = ""
                producto_mas_jugado.value = ""
                id_producto_mas_jugado.value = 0
                fumar2.value = false
                nofumar2.value = false
                sap2.value = false
                lap2.value = false
            }catch (e: Exception) {
                Log.d("Exception", "LO MAS JUGADO", e)
            }
        }
    }

    fun addObservacionesCompetencia (){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                dataObservacionesCompetencia.add(
                    ObservacionesCompetencia(
                        observaciones = observaciones_competencia.value,
                        proveedor = ID(id_provedor_competencia.value,provedor_competencia.value),
                        //tipo = calificacion_competencia.value
                ))
                id_provedor_competencia.value = 0
                provedor_competencia.value = ""
                observaciones_competencia.value = ""

                Log.d("ADDD", "OBSERVACIONES COMPETENCIA"+ dataObservacionesCompetencia)

            }catch (e: Exception) {
                Log.d("Exception", "OBSERVACIONES COMPETENCIA", e)
            }
        }
    }

    fun addComentSonido (){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                addSonido.add(
                    Sonido(
                    clasificacionComentario = ID(id_provedor_sonido_comentarios.value,provedor_sonido_comentarios.value),
                        observaciones = observaciones_sonido.value,
                        tipo = calificacion_sonido.value
                ))
                id_provedor_sonido_comentarios.value = 0
                provedor_sonido_comentarios.value = ""
                observaciones_sonido.value = ""

            }catch (e: Exception) {
                Log.d("Exception", "Detalle Ocupacion", e)
            }
        }
    }
    fun addDetalleOcupacion(){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if(statecheckBingo.value==false){
                    data.forEach {item->
                        dataProvedorOcupacion.add(item)
                    }
                }else{
                    dataSlots.forEach {item->
                        dataProvedorOcupacionSlots.add(item)
                    }
                }
                dataTime.clear()
                data.clear()
                dataSlots.clear()
                dataHorariosDeleteAlertDialog.value = Horarios()
                maquinas1_Bingo.value = ""
                maquinasLt1_Bingo.value = ""
                total_Bingo.value = ""
                addListHours()

                Log.d("HORARIOS", "HORARIOS addProvedor" + dataProvedorOcupacion )
            }catch (e: Exception) {
                Log.d("Exception", "Detalle Ocupacion", e)
            }
        }
    }
    fun addComentGeneralsJugadores (){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                dataComentariosGeneralesJugadores.add(Comentarios(
                    juego = ID(id_juego_comentarios.value,juego_comentarios.value),
                    procedencia = procedencia_comentarios.value,
                    ingresos = ingresos_comentarios.value.toInt(),
                    comentario = comentarios_jugadores.value,
                    perfil = ID(id_perfil.value,perfil_comentarios.value),
                    tipo = calificacion_comentarios.value
                ))
                id_juego_comentarios.value = 0
                juego_comentarios.value = ""
                perfil_comentarios.value = ""
                id_perfil.value = 0
                procedencia_comentarios.value = ""
                ingresos_comentarios.value = ""
                comentarios_jugadores.value = ""

                Log.d("Success", "COMENTARIOS GENERALES ARRAY"+ dataComentariosGeneralesJugadores)


            }catch (e: Exception) {
                Log.d("Exception", "COMENTARIOS GENERALES", e)
            }
        }
    }

    fun addAcumuladosBingo (){
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (evento.value==""){
                    dataAcumuladosBingo.add(Acumulados(
                        inicio = inicio.value.toInt(),
                        fin = fin.value.toInt(),
                        horaFin = "",
                        horaInicio = "",
                        evento = "",
                        premio = null,
                        proveedor = ID(id = id_proveedor_acumulados.value, nombre = proveedor_acumulados.value)
                    ))
                }else{
                    dataAcumuladosBingo.add(Acumulados(
                        inicio = inicio.value.toInt(),
                        fin = fin.value.toInt(),
                        evento = evento.value,
                        premio = premio.value.toInt(),
                        horaFin = hora_fin.value.toString(),
                        horaInicio = hora_inicio.value.toString(),
                        proveedor = ID(id = id_proveedor_acumulados.value, nombre = proveedor_acumulados.value)                    ))
                }
                id_proveedor_acumulados.value = 0
                inicio.value = ""
                fin.value = ""
                evento.value = ""
                premio.value = ""
                resta.value = "0"
                hora_inicio_TEXT.value = "Selecciona Hora"
                hora_fin_TEXT.value = "Selecciona Hora"
                proveedor_acumulados.value = ""

                Log.d("find", " EDIT VALUE ACUMULADOS"+ dataAcumuladosBingo.toString())
            }catch (e: Exception) {
                Log.d("Exception", "Acumulados", e)
            }
        }
    }

    fun postTimeCheck(delate_add:Boolean,item:String){
        dataTime.find { it.time == item }?.check = delate_add
        if(delate_add){
            dataSlots.filter { it.horario == item.toInt() }.forEach {
                dataSlots.remove(OcupacionSlots(
                    horario = item.toInt(),
                    juegoidfk = 0,
                    maquinas1 = 0,
                    ocupacionMaquinas1 = 0,
                    proveedoridfk = 0,
                    proveedor = ""
                ))
            }
            data.filter { it.horario == item.toInt() }.forEach {
                data.remove(Ocupacion(
                    horario = item.toInt(),
                    juegoidfk = 0,
                    maquinas1 = 0,
                    maquinasLt1 = 0,
                    ocupacionMaquinas1 = 0,
                    ocupacionMaquinaslt1 = 0,
                    proveedoridfk = 0,
                    proveedor = ""
                ))
            }
            data.add(Ocupacion(
                horario = item.toInt(),
                juegoidfk = 0,
                maquinas1 = 0,
                maquinasLt1 = 0,
                ocupacionMaquinas1 = 0,
                ocupacionMaquinaslt1 = 0,
                proveedoridfk = 0,
                proveedor = ""
            ))
            dataSlots.add(OcupacionSlots(
                horario = item.toInt(),
                juegoidfk = 0,
                maquinas1 = 0,
                ocupacionMaquinas1 = 0,
                proveedoridfk = 0,
                proveedor = ""
            ))
            Log.d("success", "HORARIOS ITEMS" + data )
            Log.d("success", "TIME ITEMS" + dataTime )

        }else{
            data.remove(Ocupacion(
                horario = item.toInt(),
                juegoidfk = 0,
                maquinas1 = 0,
                maquinasLt1 = 0,
                ocupacionMaquinas1 = 0,
                ocupacionMaquinaslt1 = 0,
                proveedoridfk = 0,
                proveedor = ""
            ))
            //dataTime!!.filter { it.time == item }.forEach { it.check = false }


            Log.d("success", "HORARIOS ITEMS" + data )
            Log.d("success", "TIME ITEMS" + dataTime )
        }
    }


    val _cards = MutableStateFlow(listOf<SampleData>())
    val cards: StateFlow<List<SampleData>> get() = _cards
    private val _cards2 = MutableStateFlow(listOf<SampleData>())
    val cards2: StateFlow<List<SampleData>> get() = _cards2
    private val _cards3 = MutableStateFlow(listOf<SampleData>())
    val cards3: StateFlow<List<SampleData>> get() = _cards3
    private val _cards4 = MutableStateFlow(listOf<SampleData>())
    val cards4: StateFlow<List<SampleData>> get() = _cards4
    private val _cards5 = MutableStateFlow(listOf<SampleData>())
    val cards5: StateFlow<List<SampleData>> get() = _cards5
    private val _cards6 = MutableStateFlow(listOf<SampleData>())
    val cards6: StateFlow<List<SampleData>> get() = _cards6
    private val _cards7 = MutableStateFlow(listOf<SampleData>())
    val cards7: StateFlow<List<SampleData>> get() = _cards7
    private val _cards8 = MutableStateFlow(listOf<SampleData>())
    val cards8: StateFlow<List<SampleData>> get() = _cards8
    private val _cards9 = MutableStateFlow(listOf<SampleData>())
    val cards9: StateFlow<List<SampleData>> get() = _cards9
    private val _expandedCardList = MutableStateFlow(listOf<Int>())
    val expandedCardList: StateFlow<List<Int>> get() = _expandedCardList

    init {
        getSampleData()
        addListHours()
    }

    private fun getSampleData() {
        viewModelScope.launch(Dispatchers.Default) {
            val sampleList = arrayListOf<SampleData>()
            val sampleList2 = arrayListOf<SampleData>()
            val sampleList3 = arrayListOf<SampleData>()
            val sampleList4 = arrayListOf<SampleData>()
            val sampleList5 = arrayListOf<SampleData>()
            val sampleList6 = arrayListOf<SampleData>()
            val sampleList7 = arrayListOf<SampleData>()
            val sampleList8 = arrayListOf<SampleData>()
            val sampleList9 = arrayListOf<SampleData>()
            sampleList += SampleData(id =  1, title = "Visita Promotores")
            _cards.emit(sampleList)
            sampleList2 += SampleData(id =  2, title = "Detalle Ocupación")
            _cards2.emit(sampleList2)
            sampleList3 += SampleData(id =  3, title = "Objetivo de la Visita")
            _cards3.emit(sampleList3)
            sampleList4 += SampleData(id =  4, title = "Acumulados Bingo")
            _cards4.emit(sampleList4)
            sampleList5 += SampleData(id =  5, title = "Lo más jugado Zitro y competencia")
            _cards5.emit(sampleList5)
            sampleList6 += SampleData(id =  6, title = "Comentarios Generales Jugadores")
            _cards6.emit(sampleList6)
            sampleList7 += SampleData(id =  7, title = "Comentarios Sonido Nuestras Máquinas y Proveedores Cercanos")
            _cards7.emit(sampleList7)
            sampleList8 += SampleData(id =  8, title = "Observaciones Competencia")
            _cards8.emit(sampleList8)
            sampleList9 += SampleData(id =  9, title = "Folios Técnicos")
            _cards9.emit(sampleList9)
        }
    }
    fun cardArrowClick(cardId: Int) {
        _expandedCardList.value = _expandedCardList.value.toMutableList().also { list ->
            if (list.contains(cardId)) {
                list.remove(cardId)
            } else {
                list.add(cardId)
            }
        }
    }
    fun addListHours (){
        dataTime.add(CheckTimeModel(false, "1"))
        dataTime.add(CheckTimeModel(false, "2"))
        dataTime.add(CheckTimeModel(false, "3"))
        dataTime.add(CheckTimeModel(false, "4"))
        dataTime.add(CheckTimeModel(false, "5"))
        dataTime.add(CheckTimeModel(false, "6"))
        dataTime.add(CheckTimeModel(false, "7"))
        dataTime.add(CheckTimeModel(false, "8"))
        dataTime.add(CheckTimeModel(false, "9"))
        dataTime.add(CheckTimeModel(false, "10"))
        dataTime.add(CheckTimeModel(false, "11"))
        dataTime.add(CheckTimeModel(false, "12"))
        dataTime.add(CheckTimeModel(false, "13"))
        dataTime.add(CheckTimeModel(false, "14"))
        dataTime.add(CheckTimeModel(false, "15"))
        dataTime.add(CheckTimeModel(false, "16"))
        dataTime.add(CheckTimeModel(false, "17"))
        dataTime.add(CheckTimeModel(false, "18"))
        dataTime.add(CheckTimeModel(false, "19"))
        dataTime.add(CheckTimeModel(false, "20"))
        dataTime.add(CheckTimeModel(false, "21"))
        dataTime.add(CheckTimeModel(false, "22"))
        dataTime.add(CheckTimeModel(false, "23"))
        dataTime.add(CheckTimeModel(false, "24"))
    }
}
