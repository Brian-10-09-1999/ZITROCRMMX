package com.example.zitrocrm.screens.salas.PromotorNuevaVisita.ExpandedScreens

import android.annotation.SuppressLint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.navigation.Destination
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.SampleData
import com.example.zitrocrm.repository.SharedPrefence
import com.example.zitrocrm.screens.salas.*
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertLibreriaOcupacion
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertLibreriaOcupacionSlots
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertProveedorOcupacion
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertstateHours
import com.example.zitrocrm.ui.theme.blackdark
import com.example.zitrocrm.ui.theme.graydark
import com.example.zitrocrm.utils.Val_Constants

@ExperimentalAnimationApi
@SuppressLint("UnusedTransitionTargetStateParameter")
@Composable
fun DetalleOcupacionCard(
    card2: SampleData,
    onCardArrowClick: () -> Unit,
    expanded: Boolean,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    navController: NavController,
) {
    val transitionState = remember { MutableTransitionState(expanded).apply {
        targetState = !expanded
    }}
    val transition = updateTransition(targetState = transitionState, label = "transition")
    val cardBgColor by transition.animateColor({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "bgColorTransition") {
        if (expanded) blackdark else blackdark
    }
    val cardElevation by transition.animateDp({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "elevationTransition") {
        if (expanded) 20.dp else 5.dp
    }
    val cardRoundedCorners by transition.animateDp({
        tween(
            durationMillis = Val_Constants.ExpandAnimation,
            easing = FastOutSlowInEasing
        )
    }, label = "cornersTransition") {
        15.dp
    }
    val arrowRotationDegree by transition.animateFloat({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "rotationDegreeTransition") {
        if (expanded) 0f else 180f
    }
    Card(
        backgroundColor = cardBgColor,
        elevation = cardElevation,
        shape = RoundedCornerShape(cardRoundedCorners),
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                vertical = 4.dp
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Box {
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)){
                        Image(painter = painterResource(id = R.drawable.detalles),
                            contentDescription ="IconList", modifier = Modifier.padding(start = 10.dp))
                    }
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = card2.title,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 25.dp
                                )
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)
                    ) {
                        CardArrow(
                            degrees = arrowRotationDegree,
                            onClick = onCardArrowClick
                        )
                    }
                }
            }
            DetalleOcupacionExpand(expanded,navController,viewModelPromotorNuevaVisita)
        }
    }
}

@ExperimentalAnimationApi
@Composable
fun DetalleOcupacionExpand(
    expanded: Boolean = true,
    navController: NavController,
    viewModel_PNV: PromotorNuevaVisitaViewModel,
) {
    val datastore = SharedPrefence(LocalContext.current)
    val token = datastore.getToken().toString()
    AnimatedVisibility(
        visible = expanded,
        enter = enterExpand + enterFadeIn,
        exit = exitCollapse + exitFadeOut
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(8.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()) {
                Column(modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 10.dp)) {
                    Text(
                        text = "Horarios",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 19.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Selecciona los horarios",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2)
                    Row (modifier = Modifier
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            alertstateHours.value = true
                            navController.navigate(route = Destination.Dialog.route)
                        }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, "Hora")
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 20.dp)
                        ) {
                            Row() {
                                viewModel_PNV.data.forEach { item ->
                                    Text(

                                        text = "${item.horario},",
                                        fontSize = 15.sp,
                                    )
                                }
                            }
                        }
                    }
                    var expanded by remember { mutableStateOf(false) }
                    var textfieldSize by remember { mutableStateOf(Size.Zero) }
                    val icon = if (expanded)
                        Icons.Filled.KeyboardArrowUp
                    else
                        Icons.Filled.KeyboardArrowDown
                    Column() {
                        Text(text = "Proveedor",
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(vertical = 10.dp),
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 19.sp)

                        OutlinedTextField(
                            enabled = false,
                            value = viewModel_PNV.proveedor_Ocupacion.value ,
                            onValueChange = {  },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable{
                                    navController.navigate(route = Destination.Dialog.route)
                                    alertProveedorOcupacion.value=true
                                }
                                .onGloballyPositioned { coordinates ->
                                    textfieldSize = coordinates.size.toSize()
                                }
                            ,
                            label = { Text("Proveedor") },
                            trailingIcon = {
                                Icon(icon,"contentDescription",
                                    Modifier.clickable {
                                        navController.navigate(route = Destination.Dialog.route)
                                        alertProveedorOcupacion.value=true
                                    }
                                )
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        if(viewModel_PNV.proveedor_ID_Ocupacion.value==24){
                            OutlinedTextField(
                                enabled = false,
                                value = viewModel_PNV.libreria_ocupacion.value ,
                                onValueChange = {  },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable{
                                        navController.navigate(route = Destination.Dialog.route)
                                        alertLibreriaOcupacion.value=true
                                    }
                                    .onGloballyPositioned { coordinates ->
                                        textfieldSize = coordinates.size.toSize()
                                    }
                                ,
                                label = { Text("Librería") },
                                trailingIcon = {
                                    Icon(icon,"contentDescription",
                                        Modifier.clickable {
                                            navController.navigate(route = Destination.Dialog.route)
                                            alertLibreriaOcupacion.value=true
                                        }
                                    )
                                }
                            )
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                enabled = false,
                                value = viewModel_PNV.proveedor_Ocupacion.value ,
                                onValueChange = {  },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable{
                                        //navController.navigate(route = Destination.Dialog.route)
                                        //alertProveedorOcupacion.value=true
                                    }
                                    .onGloballyPositioned { coordinates ->
                                        textfieldSize = coordinates.size.toSize()
                                    }
                                ,
                                label = { Text("Juego") },
                                trailingIcon = {
                                    Icon(icon,"contentDescription",
                                        Modifier.clickable {
                                            //navController.navigate(route = Destination.Dialog.route)
                                           // alertProveedorOcupacion.value=true
                                        }
                                    )
                                }
                            )
                            Spacer(Modifier.height(10.dp))
                        }else{
                            if (viewModel_PNV.statecheckBingo.value == true) {
                                OutlinedTextField(
                                    enabled = false,
                                    value = viewModel_PNV.libreria_ocupacion.value ,
                                    onValueChange = {  },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable{
                                            navController.navigate(route = Destination.Dialog.route)
                                            alertLibreriaOcupacionSlots.value=true
                                        }
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize = coordinates.size.toSize()
                                        }
                                    ,
                                    label = { Text("Librería") },
                                    trailingIcon = {
                                        Icon(icon,"contentDescription",
                                            Modifier.clickable {
                                                navController.navigate(route = Destination.Dialog.route)
                                                alertLibreriaOcupacionSlots.value=true
                                            }
                                        )
                                    }
                                )
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                        Text(text = "Ocupacion",
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(vertical = 10.dp),
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 19.sp)
                        val focusManager = LocalFocusManager.current

                        Column(
                            Modifier
                                .fillMaxWidth()
                        ) {
                            if (viewModel_PNV.statecheckBingo.value == false) {
                                OutlinedTextField(
                                    value = viewModel_PNV.maquinas1_Bingo.value,
                                    onValueChange = {
                                        viewModel_PNV.maquinas1_Bingo.value = it
                                        if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinas1_Bingo.value)){
                                            viewModel_PNV.total_Bingo.value =
                                                viewModel_PNV.getSum(
                                                    viewModel_PNV.maquinasLt1_Bingo.value,
                                                    viewModel_PNV.maquinas1_Bingo.value
                                                ).toString()
                                        }else{  }

                                    },
                                    label = { Text("Maquinas $1.00") },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.PointOfSale,
                                            "contentDescription",
                                            tint = Color.White
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize =
                                                coordinates.size.toSize()
                                        },
                                    keyboardActions = KeyboardActions(onDone = {
                                        focusManager.clearFocus()
                                    }),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Next,
                                        keyboardType = KeyboardType.Number
                                    ),
                                )
                                Spacer(Modifier.height(5.dp))
                                OutlinedTextField(
                                    value = viewModel_PNV.maquinasLt1_Bingo.value,
                                    onValueChange = {
                                        viewModel_PNV.maquinasLt1_Bingo.value = it
                                        if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinasLt1_Bingo.value)){
                                            viewModel_PNV.total_Bingo.value =
                                                viewModel_PNV.getSum(
                                                    viewModel_PNV.maquinasLt1_Bingo.value,
                                                    viewModel_PNV.maquinas1_Bingo.value
                                                ).toString()
                                        }else{  }
                                    },
                                    label = { Text("Maquinas < $1.00") },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.PointOfSale,
                                            "contentDescription",
                                            tint = Color.White
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize =
                                                coordinates.size.toSize()
                                        },
                                    keyboardActions = KeyboardActions(onDone = {
                                        focusManager.clearFocus() }),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Next,
                                        keyboardType = KeyboardType.Number
                                    )
                                )
                                Spacer(Modifier.height(5.dp))
                                OutlinedTextField(
                                    value = viewModel_PNV.total_Bingo.value,
                                    onValueChange = { /*total_maquina.value = it*/ },
                                    label = { Text("Total") },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.PointOfSale,
                                            "contentDescription",
                                            tint = Color.White
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize =
                                                coordinates.size.toSize()
                                        },
                                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Done,
                                        keyboardType = KeyboardType.Number
                                    )
                                )
                            } else {
                                Spacer(Modifier.height(5.dp))
                                OutlinedTextField(
                                    value = viewModel_PNV.maquinas1_Bingo.value,
                                    onValueChange = {
                                        viewModel_PNV.maquinas1_Bingo.value = it
                                        viewModel_PNV.maquinasLt1_Bingo.value = "0"
                                        if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinas1_Bingo.value)){
                                            viewModel_PNV.total_Bingo.value =
                                                viewModel_PNV.getSum(
                                                    viewModel_PNV.maquinasLt1_Bingo.value,
                                                    viewModel_PNV.maquinas1_Bingo.value
                                                ).toString()
                                        }else{  }



                                    },
                                    label = { Text("Maquinas") },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.PointOfSale,
                                            "contentDescription",
                                            tint = Color.White
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize =
                                                coordinates.size.toSize()
                                        },
                                    keyboardActions = KeyboardActions(onDone = {
                                        focusManager.clearFocus()
                                        viewModel_PNV.sumOcupacionSlots()
                                    }),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Done,
                                        keyboardType = KeyboardType.Number
                                    )
                                )
                                Spacer(Modifier.height(5.dp))

                                OutlinedTextField(
                                    value = viewModel_PNV.total_Bingo.value,
                                    onValueChange = { },
                                    label = { Text("Total") },
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.PointOfSale,
                                            "contentDescription",
                                            tint = Color.White
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onGloballyPositioned { coordinates ->
                                            textfieldSize =
                                                coordinates.size.toSize()
                                        },
                                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                    keyboardOptions = KeyboardOptions(
                                        imeAction = ImeAction.Done,
                                        keyboardType = KeyboardType.Number
                                    )
                                )
                            }
                        }
                        var enabled by remember {mutableStateOf(false)}
                        Spacer(Modifier.height(5.dp))

                        viewModel_PNV.data.forEach { item ->
                            viewModel_PNV.addinfoArrayOcupacion(token,item.horario)
                            val maquinas1_Bingo = remember { mutableStateOf(item.ocupacionMaquinas1.toString()) }
                            val maquinasLt1_Bingo = remember { mutableStateOf(item.ocupacionMaquinaslt1.toString()) }
                            val totalOcupacionBIngo2 = remember { mutableStateOf("") }
                            Spacer(Modifier.height(10.dp))
                            Card(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(colorResource(R.color.blackdark))
                                    .clip(RoundedCornerShape(5))
                            ) {
                                Column(Modifier.padding(5.dp)) {
                                    Text(
                                        text = "${item.horario}:00 hrs",
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    )
                                    Spacer(Modifier.height(3.dp))
                                    if (viewModel_PNV.statecheckBingo.value == false) {
                                        OutlinedTextField(
                                            value = maquinas1_Bingo.value,
                                            onValueChange = {
                                                maquinas1_Bingo.value = it
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinas1_Bingo.value)){ }else{ viewModel_PNV.maquinas1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinasLt1_Bingo.value)){ }else{ viewModel_PNV.maquinasLt1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.total_Bingo.value)){ }else{ viewModel_PNV.total_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(maquinas1_Bingo.value)){
                                                    if(maquinasLt1_Bingo.value==""){
                                                        if(maquinas1_Bingo.value==""){
                                                        }else {
                                                            if(maquinas1_Bingo.value.toInt()>viewModel_PNV.maquinas1_Bingo.value.toInt()){
                                                                maquinas1_Bingo.value = viewModel_PNV.maquinas1_Bingo.value
                                                            }
                                                        }
                                                    }else{
                                                        if(maquinas1_Bingo.value==""){
                                                        }else {
                                                            if(viewModel_PNV.getValidationSum(maquinasLt1_Bingo.value)){
                                                                if(maquinas1_Bingo.value.toInt()>viewModel_PNV.maquinas1_Bingo.value.toInt()){
                                                                    maquinas1_Bingo.value = viewModel_PNV.maquinas1_Bingo.value
                                                                }
                                                                if(maquinasLt1_Bingo.value.toInt()>viewModel_PNV.maquinasLt1_Bingo.value?.toInt()){
                                                                    maquinasLt1_Bingo.value = viewModel_PNV.maquinasLt1_Bingo.value
                                                                }
                                                            }
                                                        }
                                                    }
                                                    totalOcupacionBIngo2.value = viewModel_PNV.getPorcentaje(viewModel_PNV.getSum(maquinasLt1_Bingo.value, maquinas1_Bingo.value).toString(), viewModel_PNV.total_Bingo.value).toString()
                                                    if(viewModel_PNV.getValidationSum(maquinasLt1_Bingo.value)){
                                                        viewModel_PNV.itemhorarioArray(item.horario,maquinas1_Bingo.value.toInt(),maquinasLt1_Bingo.value.toInt())
                                                        if(viewModel_PNV.proveedor_ID_Ocupacion.value>0){
                                                            enabled = true
                                                        }
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .onGloballyPositioned { coordinates ->
                                                    textfieldSize =
                                                        coordinates.size.toSize()
                                                },
                                            label = { Text("Ocupación $ 1.00") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.PriceCheck,
                                                    "contentDescription",
                                                    tint = Color.White
                                                )
                                            },
                                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                            keyboardOptions = KeyboardOptions(
                                                imeAction = ImeAction.Next,
                                                keyboardType = KeyboardType.Number
                                            )
                                        )
                                        OutlinedTextField(
                                            value = maquinasLt1_Bingo.value,
                                            onValueChange = {
                                                maquinasLt1_Bingo.value = it
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinas1_Bingo.value)){ }else{ viewModel_PNV.maquinas1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinasLt1_Bingo.value)){ }else{ viewModel_PNV.maquinasLt1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.total_Bingo.value)){ }else{ viewModel_PNV.total_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(maquinasLt1_Bingo.value)){
                                                    if(maquinas1_Bingo.value==""){
                                                        if(maquinasLt1_Bingo.value==""){
                                                        }else {
                                                            if(maquinasLt1_Bingo.value?.toInt()>viewModel_PNV.maquinasLt1_Bingo.value?.toInt()){
                                                                maquinasLt1_Bingo.value = viewModel_PNV.maquinasLt1_Bingo.value
                                                            }
                                                        }
                                                    }else{
                                                        if(maquinasLt1_Bingo.value==""){
                                                        }else {
                                                            if(viewModel_PNV.getValidationSum(maquinas1_Bingo.value)){
                                                                if(maquinas1_Bingo.value.toInt()>viewModel_PNV.maquinas1_Bingo.value.toInt()){
                                                                    maquinas1_Bingo.value = viewModel_PNV.maquinas1_Bingo.value
                                                                }
                                                                if(maquinasLt1_Bingo.value?.toInt()>viewModel_PNV.maquinasLt1_Bingo.value?.toInt()){
                                                                    maquinasLt1_Bingo.value = viewModel_PNV.maquinasLt1_Bingo.value
                                                                }
                                                            }
                                                        }
                                                    }
                                                    totalOcupacionBIngo2.value = viewModel_PNV.getPorcentaje(viewModel_PNV.getSum(maquinasLt1_Bingo.value, maquinas1_Bingo.value).toString(), viewModel_PNV.total_Bingo.value).toString()
                                                    if(viewModel_PNV.getValidationSum(maquinas1_Bingo.value)){
                                                        viewModel_PNV.itemhorarioArray(item.horario,maquinas1_Bingo.value.toInt(),maquinasLt1_Bingo.value.toInt())
                                                        if(viewModel_PNV.proveedor_ID_Ocupacion.value>0){
                                                            enabled = true
                                                        }
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .onGloballyPositioned { coordinates ->
                                                    textfieldSize =
                                                        coordinates.size.toSize()
                                                },
                                            label = { Text("Ocupación < $ 1.00") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.PriceCheck,
                                                    "contentDescription",
                                                    tint = Color.White
                                                )
                                            },
                                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                            keyboardOptions = KeyboardOptions(
                                                imeAction = ImeAction.Done,
                                                keyboardType = KeyboardType.Number
                                            )
                                        )
                                        OutlinedTextField(
                                            value = totalOcupacionBIngo2.value,
                                            onValueChange = {  },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .onGloballyPositioned { coordinates ->
                                                    textfieldSize =
                                                        coordinates.size.toSize()
                                                },
                                            label = { Text("Ocupacion %") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.PointOfSale,
                                                    "contentDescription",
                                                    tint = Color.White
                                                )
                                            },
                                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                            keyboardOptions = KeyboardOptions(
                                                imeAction = ImeAction.Done,
                                                keyboardType = KeyboardType.Number
                                            )
                                        )
                                        Spacer(Modifier.height(10.dp))
                                    } else {
                                        OutlinedTextField(
                                            value = maquinas1_Bingo.value,
                                            onValueChange = {
                                                maquinas1_Bingo.value = it
                                                maquinasLt1_Bingo.value = "0"
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinas1_Bingo.value)){ }else{ viewModel_PNV.maquinas1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.maquinasLt1_Bingo.value)){ }else{ viewModel_PNV.maquinasLt1_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(viewModel_PNV.total_Bingo.value)){ }else{ viewModel_PNV.total_Bingo.value = "0" }
                                                if(viewModel_PNV.getValidationSum(maquinas1_Bingo.value)){
                                                    if(maquinasLt1_Bingo.value==""){
                                                        if(maquinas1_Bingo.value==""){
                                                        }else {
                                                            if(maquinas1_Bingo.value.toInt()>viewModel_PNV.maquinas1_Bingo.value.toInt()){
                                                                maquinas1_Bingo.value = viewModel_PNV.maquinas1_Bingo.value
                                                            }
                                                        }
                                                    }else{
                                                        if(maquinas1_Bingo.value==""){
                                                        }else {
                                                            if(maquinas1_Bingo.value.toInt()>viewModel_PNV.maquinas1_Bingo.value.toInt()){
                                                                maquinas1_Bingo.value = viewModel_PNV.maquinas1_Bingo.value
                                                            }
                                                            if(maquinasLt1_Bingo.value?.toInt()>viewModel_PNV.maquinasLt1_Bingo.value?.toInt()){
                                                                maquinasLt1_Bingo.value = viewModel_PNV.maquinasLt1_Bingo.value
                                                            }
                                                        }
                                                    }
                                                    totalOcupacionBIngo2.value = viewModel_PNV.getPorcentaje(viewModel_PNV.getSum(maquinasLt1_Bingo.value, maquinas1_Bingo.value).toString(), viewModel_PNV.total_Bingo.value).toString()
                                                    viewModel_PNV.itemhorarioArray(item.horario,maquinas1_Bingo.value.toInt(),maquinasLt1_Bingo.value.toInt())
                                                    if(viewModel_PNV.proveedor_ID_Ocupacion.value>0){
                                                        enabled = true
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .onGloballyPositioned { coordinates ->
                                                    textfieldSize =
                                                        coordinates.size.toSize()
                                                },
                                            label = { Text("Ocupación") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.PriceCheck,
                                                    "contentDescription",
                                                    tint = Color.White
                                                )
                                            },
                                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                            keyboardOptions = KeyboardOptions(
                                                imeAction = ImeAction.Done,
                                                keyboardType = KeyboardType.Number
                                            )
                                        )
                                        OutlinedTextField(
                                            value = totalOcupacionBIngo2.value,
                                            onValueChange = {},
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .onGloballyPositioned { coordinates ->
                                                    textfieldSize =
                                                        coordinates.size.toSize()
                                                },
                                            label = { Text("Ocupacion %") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Filled.PointOfSale,
                                                    "contentDescription",
                                                    tint = Color.White
                                                )
                                            },
                                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                                            keyboardOptions = KeyboardOptions(
                                                imeAction = ImeAction.Done,
                                                keyboardType = KeyboardType.Number
                                            )
                                        )
                                        Spacer(Modifier.height(10.dp))
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Button(
                            enabled = enabled,
                            onClick = {viewModel_PNV.addDetalleOcupacion()
                                enabled = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp),
                            elevation = ButtonDefaults.elevation(defaultElevation = 5.dp),
                            shape = RoundedCornerShape(10),
                            colors = ButtonDefaults.buttonColors(backgroundColor = colorResource(id = R.color.reds)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Precio Inicio",
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        if(viewModel_PNV.statecheckBingo.value==false){
                            viewModel_PNV.dataProvedorOcupacion.forEach { item ->
                                Card(modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp)) {
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.SnippetFolder, "Diferencia")
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(horizontal = 20.dp)
                                        ) {
                                            Text(
                                                text = "Proveedor:  ${item.proveedor} \nHorario: "+item.horario!!.toString()+":00 hrs",
                                                fontSize = 15.sp,
                                                textAlign = TextAlign.Start,
                                                modifier = Modifier.padding(vertical = 15.dp, horizontal = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }else{
                            viewModel_PNV.dataProvedorOcupacionSlots.forEach { item ->
                                Card(modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 5.dp)) {
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.SnippetFolder, "Diferencia")
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(horizontal = 20.dp)
                                        ) {
                                            Text(
                                                text = "Proveedor:  ${item.proveedor} \nHorario: "+item.horario!!.toString()+":00 hrs",
                                                fontSize = 15.sp,
                                                textAlign = TextAlign.Start,
                                                modifier = Modifier.padding(vertical = 15.dp, horizontal = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
