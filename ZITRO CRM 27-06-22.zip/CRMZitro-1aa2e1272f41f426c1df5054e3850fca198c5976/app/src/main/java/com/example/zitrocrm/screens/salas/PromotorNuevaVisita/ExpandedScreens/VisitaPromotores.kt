package com.example.zitrocrm.screens.salas.PromotorNuevaVisita.ExpandedScreens

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.DatePicker
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Timer
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalTextInputService
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.navigation.Destination
import com.example.zitrocrm.network.models_dto.SalasNuevoReporte.SampleData
import com.example.zitrocrm.screens.salas.*
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.PromotorNuevaVisitaViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertObjetivoSemanal
import com.example.zitrocrm.ui.theme.blackdark
import com.example.zitrocrm.ui.theme.graydark
import com.example.zitrocrm.utils.Val_Constants
import java.util.*


@ExperimentalAnimationApi
@SuppressLint("UnusedTransitionTargetStateParameter")
@Composable
fun VisitaPromotoresCard(
    card: SampleData,
    onCardArrowClick: () -> Unit,
    expanded: Boolean,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    navController: NavController,
) {
    Column(
        modifier = Modifier
            .padding(bottom = 10.dp, top = 10.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(blackdark)
            .fillMaxWidth()
            .size(80.dp),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Image(
            painter = painterResource(R.drawable.reporte_visitas_icon),
            contentDescription = "",
            modifier = Modifier
                .padding(0.dp)
                .size(50.dp)
        )
        Text(
            text = "Nueva Visita",
            style = MaterialTheme.typography.subtitle2,
            fontSize = 16.sp
        )
    }
    val transitionState = remember { MutableTransitionState(expanded).apply {
        targetState = !expanded
    }}
    val transition = updateTransition(targetState = transitionState, label = "transition")
    val cardBgColor by transition.animateColor({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "bgColorTransition") {
        if (expanded) blackdark else blackdark
    }
    val cardElevation by transition.animateDp({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "elevationTransition") {
        if (expanded) 20.dp else 5.dp
    }
    val cardRoundedCorners by transition.animateDp({
        tween(
            durationMillis = Val_Constants.ExpandAnimation,
            easing = FastOutSlowInEasing
        )
    }, label = "cornersTransition") {
        15.dp
    }
    val arrowRotationDegree by transition.animateFloat({
        tween(durationMillis = Val_Constants.ExpandAnimation)
    }, label = "rotationDegreeTransition") {
        if (expanded) 0f else 180f
    }
    Card(
        backgroundColor = cardBgColor,
        elevation = cardElevation,
        shape = RoundedCornerShape(cardRoundedCorners),
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                vertical = 4.dp
            )
    ) { Column(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Box {
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)){
                        Image(painter = painterResource(id = R.drawable.reporte_visitas_icon),
                            contentDescription ="IconList", modifier = Modifier.padding(start = 10.dp))
                    }
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = card.title,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    horizontal = 12.dp,
                                    vertical = 25.dp
                                )
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.15f)
                            .align(Alignment.CenterVertically)
                    ) {
                        CardArrow(
                            degrees = arrowRotationDegree,
                            onClick = onCardArrowClick
                        )
                    }
                }
            }
            VisitaPromotoresExpand(expanded,viewModelPromotorNuevaVisita, navController)
        }
    }
}

@ExperimentalAnimationApi
@Composable
fun VisitaPromotoresExpand(
    expanded: Boolean = true,
    viewModelPromotorNuevaVisita: PromotorNuevaVisitaViewModel,
    navController: NavController,
) {
    AnimatedVisibility(
        visible = expanded,
        enter = enterExpand + enterFadeIn,
        exit = exitCollapse + exitFadeOut
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(8.dp)
        ) {
            Box(
                Modifier
                    .fillMaxSize()) {
                Column(modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 10.dp)) {
                    val mContext = LocalContext.current
                    val mYear: Int
                    val mMonth: Int
                    val mDay: Int
                    val mCalendar = Calendar.getInstance()
                    val mHour = mCalendar.get(Calendar.HOUR_OF_DAY)
                    val mMinute = mCalendar.get(Calendar.HOUR_OF_DAY)
                    mYear = mCalendar.get(Calendar.YEAR)
                    mMonth = mCalendar.get(Calendar.MONTH)
                    mDay = mCalendar.get(Calendar.DAY_OF_MONTH)
                    mCalendar.time = Date()
                    val mDatePickerDialog = DatePickerDialog(
                        mContext,
                        { _: DatePicker, mYear: Int, mMonth: Int, mDayOfMonth: Int ->
                            viewModelPromotorNuevaVisita.fecha_visita.value = "$mDayOfMonth-${mMonth+1}-$mYear"
                            viewModelPromotorNuevaVisita.mDayOfMonth.value = mDayOfMonth
                            viewModelPromotorNuevaVisita.Month.value = mMonth+1
                            viewModelPromotorNuevaVisita.mYear.value = mYear
                        }, mYear, mMonth, mDay
                    )
                    val mTimePickerDialogEntrada = TimePickerDialog(
                        mContext,
                        {_, mHour : Int, mMinute: Int ->
                            viewModelPromotorNuevaVisita.inicio_visita_TEXT.value = "$mHour:00 hrs"
                            viewModelPromotorNuevaVisita.inicio_visita.value = mHour
                        }, mHour, mMinute, true
                    )
                    val mTimePickerDialogSalida = TimePickerDialog(
                        mContext,
                        {_, mHour : Int, mMinute : Int ->
                            viewModelPromotorNuevaVisita.fin_visita_TEXT.value = "$mHour:00 hrs"
                            viewModelPromotorNuevaVisita.fin_visita.value = mHour
                        }, mHour, mMinute, true
                    )
                    Text(
                        text = "Fecha de Visita",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp
                    )
                    Row (modifier = Modifier
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { mDatePickerDialog.show() }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.DateRange, "Fecha")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.fecha_visita.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    Text(
                        text = "Hora de Entrada",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp)

                    Row (modifier = Modifier
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { mTimePickerDialogEntrada.show() }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, "Hora")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.inicio_visita_TEXT.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    Text(
                        text = "Hora de Salida",
                        fontStyle = FontStyle.Normal,
                        modifier = Modifier.align(Alignment.Start),
                        style = MaterialTheme.typography.subtitle2,
                        fontSize = 16.sp)

                    Row (modifier = Modifier
                        .padding(vertical = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { mTimePickerDialogSalida.show() }
                        .height(50.dp)
                        .fillMaxWidth()
                        .background(color = graydark)
                        .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, "Hora")
                        Box(modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 20.dp)) {
                            Text(text = viewModelPromotorNuevaVisita.fin_visita_TEXT.value,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Start)
                        }
                    }
                    var expanded by remember { mutableStateOf(false) }
                    var textfieldSize by remember { mutableStateOf(Size.Zero) }
                    val icon = if (expanded)
                        Icons.Filled.KeyboardArrowUp
                    else
                        Icons.Filled.KeyboardArrowDown
                    Column() {
                        Text(
                            text = "Objetivo Semanal",
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(vertical = 15.dp),
                            style = MaterialTheme.typography.subtitle2,
                            fontSize = 19.sp
                        )
                        CompositionLocalProvider(
                            LocalTextInputService provides null
                        ) {
                            OutlinedTextField(
                                //enabled = false,
                                value = viewModelPromotorNuevaVisita.objetivoSemanal_visita.value,
                                onValueChange = { viewModelPromotorNuevaVisita.objetivoSemanal_visita.value },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        alertObjetivoSemanal.value = true
                                        navController.navigate(route = Destination.Dialog.route)
                                    }
                                    .onGloballyPositioned { coordinates ->
                                        textfieldSize = coordinates.size.toSize()
                                    },
                                label = { Text("Objetivo Semanal") },
                                trailingIcon = {
                                    Icon(icon, "contentDescription",
                                        Modifier.clickable {
                                            alertObjetivoSemanal.value = true
                                            navController.navigate(route = Destination.Dialog.route)
                                        }
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
