package com.example.zitrocrm.network.models_dto

data class CheckTimeModel (var check : Boolean, val time : String)