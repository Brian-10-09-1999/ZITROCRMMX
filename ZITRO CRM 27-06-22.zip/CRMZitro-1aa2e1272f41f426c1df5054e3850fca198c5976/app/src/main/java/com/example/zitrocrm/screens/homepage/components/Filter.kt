package com.example.zitrocrm.screens.homepage.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.zitrocrm.R
import com.example.zitrocrm.navigation.Destination
import com.example.zitrocrm.network.models_dto.Filter.FilterViewModel
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertClientesFilter
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertRegionFilter
import com.example.zitrocrm.screens.salas.PromotorNuevaVisita.components.alertSalasFilter
import com.example.zitrocrm.ui.theme.reds
import com.example.zitrocrm.repository.SharedPrefence
import com.example.zitrocrm.screens.login.components.ErrorImageAuth
import com.example.zitrocrm.screens.login.components.ProgressBarLoading

@Composable
fun FilterScreen(navController: NavController){
    val filterviewmodel: FilterViewModel= viewModel()
    Scaffold(
    topBar = {
        TopAppBar(
            elevation = 0.dp,
            modifier = Modifier.height(70.dp),
            title = {
                Box(modifier = Modifier.fillMaxSize()) {

                    Image(
                        painter = painterResource(R.drawable.crm_logo),
                        contentDescription = "",
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(5.dp)
                    )
                }
            },
            backgroundColor = reds,
        )
    }
    ) {
        Column() {
            dropDownMenuCliente(navController,filterviewmodel)
        }
    }
}




@Composable
private fun dropDownMenuCliente(
    navController: NavController,
    viewModel: FilterViewModel
    /**onclickLogin: (selectedText: String, selectedText2: String, selectedText3: String)**/)
{
    var expanded by remember { mutableStateOf(false) }
    var textfieldSize by remember { mutableStateOf(Size.Zero)}
    val datastore = SharedPrefence(LocalContext.current)
    val cliente = ""+datastore.getCliente()
    val region = ""+datastore.getRegion()
    val redionid = datastore.getRegionId()
    val salas = ""+datastore.getSala()
    val token = datastore.getToken()
    val icon = if (expanded)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown
    val icon2 = if (expanded)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown
    val icon3 = if (expanded)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown

    Column(Modifier.padding(20.dp)) {

        Text(
            text = "Filtrar Busqueda",
            modifier = Modifier
                .padding(vertical = 15.dp)
                .align(alignment = Alignment.CenterHorizontally),
            style = MaterialTheme.typography.subtitle2,
            fontSize = 19.sp,
            color = Color.White
        )

        OutlinedTextField(
            value = cliente,
            onValueChange = { cliente },
            modifier = Modifier
                .fillMaxWidth()
                .onGloballyPositioned { coordinates ->
                    textfieldSize = coordinates.size.toSize()
                },
            label = { Text("Cliente") },
            trailingIcon = {
                Icon(icon, "contentDescription",
                    Modifier.clickable { alertClientesFilter.value = true
                        navController.navigate(route = Destination.Dialog.route)
                    })
            }
        )
    }

    Column(Modifier.padding(20.dp)) {
        OutlinedTextField(
            value = region,
            onValueChange = { region },
            modifier = Modifier
                .fillMaxWidth()
                .onGloballyPositioned { coordinates ->
                    //This value is used to assign to the DropDown the same width
                    textfieldSize = coordinates.size.toSize()
                },
            label = {Text("Region")},
            trailingIcon = {
                Icon(icon2,"contentDescription",
                    Modifier.clickable { alertRegionFilter.value=true
                        navController.navigate(route = Destination.Dialog.route)
                    }
                )
            }
        )
    }

    Column(Modifier.padding(20.dp)) {
        OutlinedTextField(
            value = salas,
            onValueChange = { salas },
            modifier = Modifier
                .fillMaxWidth()
                .onGloballyPositioned { coordinates ->
                    //This value is used to assign to the DropDown the same width
                    textfieldSize = coordinates.size.toSize()
                },
            label = {Text("Sala")},
            trailingIcon = {
                Icon(icon3,"contentDescription",
                    Modifier.clickable {
                        alertSalasFilter.value=true
                        navController.navigate(route = Destination.Dialog.route)
                    }
                )
            }
        )
    }
    Column(modifier = Modifier.padding(20.dp)) {
        Button(
            onClick = {
                navController.popBackStack()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),

            shape = RoundedCornerShape(10),
            colors = ButtonDefaults.buttonColors(
                backgroundColor = colorResource(id = R.color.reds)
            )
        ) {
            Text(
                text = "Filtrar",
                fontSize = 20.sp,
                color = Color.White
            )
        }
    }
}





