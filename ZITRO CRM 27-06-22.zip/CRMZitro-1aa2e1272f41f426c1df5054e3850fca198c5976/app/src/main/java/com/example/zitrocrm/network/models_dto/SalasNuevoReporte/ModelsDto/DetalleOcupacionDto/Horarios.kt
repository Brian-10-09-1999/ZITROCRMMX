package com.example.zitrocrm.network.models_dto.DetalleOcupacionDto

import com.google.gson.annotations.SerializedName


data class Horarios (
  @SerializedName("horario"      ) var horario      : String? = null,
  @SerializedName("ocupacion1"   ) var ocupacion1   : String? = null,
  @SerializedName("ocupacionLt1" ) var ocupacionLt1 : String? = null,
  @SerializedName("porcentaje"   ) var porcentaje   : String? = null,
)